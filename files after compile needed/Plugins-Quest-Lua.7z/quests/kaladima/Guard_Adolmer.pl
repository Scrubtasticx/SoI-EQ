sub EVENT_WAYPOINT_ARRIVE {
if($wp eq 4) {
	plugin::DoAnim(kneel);
	}
}
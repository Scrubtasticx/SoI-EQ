sub EVENT_DEATH_COMPLETE {
  quest::say("Omakin the Stalker looks at you with a kind expression. The large creature smiles at you and motions for you to move away. Perhaps it senses that you have more adventure ahead of you. Its form begins to loosen, as if it were a mirage produced by the jungle heat.");
}
sub EVENT_AGGRO {
  quest::say("Your bones will be crushed by the Kromzek of Kael Drakkel!");
}

# Quest by mystic414
sub EVENT_SIGNAL {
  if ($signal == 66){
     quest::shout("BEWARE! BEWARE! The Sleeper has been awakened! He means death for all who remain here! Time is short, flee the Skyshrine now if you value your life!");
 }
}

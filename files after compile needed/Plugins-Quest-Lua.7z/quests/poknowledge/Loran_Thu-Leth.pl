sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("If you are in need of poisons. then your presence is not a waste of my time. However. if you seek idle chit-chat or have come for some other affair than to purchase my wares. begone with you. I haven't the time nor the desire to engage in activities that will not yield me profit."); }
}
#END of FILE Zone:poknowledge  ID:202077 -- Loran_Thu`Leth 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to New Tanaan. traveler. and know that you are among allies in the quest for knowledge and personal enlightenment. All of New Tanaan's residents have strived for the past weeks to accommodate every visitor's needs as we can. Collectively. we have proven to be without a match in our efforts to do so. as the knowledge kept here is seemingly infinite. Individually. however. we hold specialties that one must take into account before judging us as the proper aid for your current quest. If your life is dedicated to the ways of the priest. despite the mode of your faith. then I may be of service to you. My inventory is stocked. as I am sure that it shall always be. Search it at your convenience and leisure should you wish it."); }
}
#END of FILE Zone:poknowledge  ID:202219 -- Vicar_Glaunn 


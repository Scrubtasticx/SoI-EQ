sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("If you are not an adept in the ways of poison making. then be off with you. I have neither the time nor the desire to stand idle and make pointless chit-chat with anyone. else it yields a considerable profit worthy of my time."); }
}
#END of FILE Zone:poknowledge  ID:202141 -- Ciren_Darkbog 


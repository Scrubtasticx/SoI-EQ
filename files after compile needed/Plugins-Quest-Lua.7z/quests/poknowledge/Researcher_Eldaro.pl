sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Salutations stranger. I wish to continue to my study of the multitude of tomes stored here in the Great Library of New Tanaan. If you are interested in tomes relative to the history of the Erudite people then I shall permit you to borrow these tomes I have located. The tomes will be returned when you are done with them by the magics of New Tanaan. If you are not interested in these tomes then I shall end our conversation now and return to my studies."); }
}
#END of FILE Zone:poknowledge  ID:202022 -- Researcher_Eldaro 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name. If you have come searching to restock on goods. then I am most glad to see you. Please. browse my wares and purchase whatever you need from my stock."); }
}
#END of FILE Zone:poknowledge  ID:202130 -- Amile_Pitt 


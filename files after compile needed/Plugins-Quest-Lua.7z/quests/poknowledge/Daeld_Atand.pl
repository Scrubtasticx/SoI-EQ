sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail and well met. my friend! If you have come searching for supplies needed to fish out of the fair waters of Norrath. than you have come to the right place. Please. search my inventory as you wish -- I'm certain that what you seek is right here. If for some reason I do not carry the rare item you desire at this moment. then seek out Ramos Jerwan. for he likely shall."); }
}
#END of FILE Zone:poknowledge  ID:202063 -- Daeld_Atand 


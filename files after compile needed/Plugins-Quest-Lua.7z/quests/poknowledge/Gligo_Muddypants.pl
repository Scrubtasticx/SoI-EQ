sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Oh. hello there. $name! If you are searching for pottery materials. well then my friend. you have certainly come to the right place. Come and search my wares. if you wish it. I guarantee that my prices are most fair.'"); }
}
#END of FILE Zone:poknowledge  ID:202132 -- Gligo_Muddypants 


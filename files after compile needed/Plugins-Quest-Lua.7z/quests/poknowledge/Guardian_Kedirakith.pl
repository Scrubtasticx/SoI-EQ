sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("grins a wide toothy smile and says. 'You may want to watch yourself. unless you are looking to enter a painful situation.  The portals in this district will lead someone of your race to a city of the wrong alignment.  If you use the portals and end up in the wrong place. you'll be crushed for certain.'"); }
}
#END of FILE Zone:poknowledge  ID:202103 -- Guardian_Kedirakith 


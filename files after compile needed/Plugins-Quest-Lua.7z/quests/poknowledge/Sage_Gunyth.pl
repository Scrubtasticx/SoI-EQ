sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("turns a condescending eye toward you. 'I am quite busy here. and I do not appreciate interruptions.  My [research] is important. and I do not have time to explain everything to you.'"); }
}
#END of FILE Zone:poknowledge  ID:202045 -- Sage_Gunyth 


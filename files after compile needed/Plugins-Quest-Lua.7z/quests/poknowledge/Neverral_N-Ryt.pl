sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings traveler. If you have come to New Tanaan seeking knowledge then perhaps these books I have uncovered in great library will interest you. You may borrow them and the magic of New Tanaan will return them to their place in the library when you are through."); }
}
#END of FILE Zone:poknowledge  ID:202167 -- Neverral_N`Ryt 


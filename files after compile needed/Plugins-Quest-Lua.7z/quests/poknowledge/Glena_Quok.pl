sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("gives a warm. toothy smile and pleasant nod of her head in greeting. 'An' good day t'ye. $name! Well. what might 'have brought ye t'old Glena Quok. Hrm? Perhaps ye be a distinguished member o'the blacksmithin' arts. aye? Well. if that indeed be the case. then we certaintly be in luck! I am a bit familiar with the trade meself an' offer me services t'any smith who may 'ave use fer what I am offerin' at the time. Dinnae be shy. friend! Search me wares if ye be interested and purchase what ye like.'"); }
}
#END of FILE Zone:poknowledge  ID:202088 -- Glena_Quok 


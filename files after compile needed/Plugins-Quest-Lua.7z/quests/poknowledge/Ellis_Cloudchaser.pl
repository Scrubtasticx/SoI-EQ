sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Well. good day to you my friend. and welcome! We of New Tanaan are quite excited with the recent influx of foreigners into our fair hamlet in the cosmos -- but I ramble without speech of business. If you are a fletcher in trade. then you have certainly come to the right place. for you will not find prices more fair or supplies more generous in any region upon Norrath as you will here. in New Tanaan."); }
}
#END of FILE Zone:poknowledge  ID:202075 -- Ellis_Cloudchaser 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello. traveler. New Tanaan greets you warmly and with the utmost respect. We only hope that you may return to us the same indifference and non prejudicial regard for knowledge and self-progression as we have founded this city upon for a timeless age. I myself was once a traveler as you are now -- exploring the world in search of adventure. wealth. fame. and glory. I am an enchanter. though now I exist as a scholar and researcher of my art. I. like so many other citizens of New Tanaan. have volunteered to give my knowledge unto those willing to accept it. If you are of the same art as I. perhaps you would wish to search my inventory. I have penned many spells from the memories of my youth and you may find something of interest amongst my collection."); }
}
#END of FILE Zone:poknowledge  ID:202212 -- Illusionist_Sevat 


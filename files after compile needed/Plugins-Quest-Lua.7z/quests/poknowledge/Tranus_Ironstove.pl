sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Aaah. . . good day to you. my friend. and welcome! It has been a most exciting time these past few weeks with the influx of young and seasoned adventurers alike. It has been quite difficult to keep up on our stock. but do not be discouraged. for Tranus Ironstove's supplies are always well-kept! If you are in need of baking supplies. then search my wares and perhaps I might hold that which you seek."); }
}
#END of FILE Zone:poknowledge  ID:202090 -- Tranus_Ironstove 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello. traveler. If you be interested in brewing. then you've come to the right man. My wares are for producing the most tasty beverages in all of New Tanaan. and they are yours to purchase should you wish."); }
}
#END of FILE Zone:poknowledge  ID:202134 -- Bargol_Halith 


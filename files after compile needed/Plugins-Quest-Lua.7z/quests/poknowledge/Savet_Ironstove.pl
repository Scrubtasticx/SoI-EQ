sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name. and welcome to New Tanaan. This city holds a great variety of supplies for all tradesmen -- you shall not find such a welcoming host of merchants gathered in one city upon Norrath. I guarantee! Come. if you be a baker. and search my inventory. Perhaps you shall find something of interest or necessity to your search."); }
}
#END of FILE Zone:poknowledge  ID:202092 -- Savet_Ironstove 


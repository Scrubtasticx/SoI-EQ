sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Good day. traveler. I am Kirem Deepfacet and as a merchant of precious metals and stones. I serve this city. which has been most gracious in providing a home away from the turmoil of Norrath. If you seek supplies to craft jewelry of all sorts. then do not hesitate to search my inventory."); }
}
#END of FILE Zone:poknowledge  ID:202131 -- Kirem_Deepfacet 


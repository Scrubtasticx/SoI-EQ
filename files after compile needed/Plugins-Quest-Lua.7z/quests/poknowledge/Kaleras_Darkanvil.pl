sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Good day t'ye. traveler. If ye be in need of smithin' supplies. then ye've certainly come t'the right place. friend! The Darkanvils have many supplies needed for crafting some of the finest weapons and armor the universe has ever seen. and they are offered t'ye. . . At a fair price. a'course."); }
}
#END of FILE Zone:poknowledge  ID:202148 -- Kaleras_Darkanvil 


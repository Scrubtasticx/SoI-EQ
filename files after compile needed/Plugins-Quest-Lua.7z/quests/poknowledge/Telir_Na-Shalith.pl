sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Whatever your affair or business is -- if it is not with the intent to purchase supplies to poison your blade -- I suggest that you move along for I have neither the time nor the care to hold meaningless dialogue with one who will not bear unto me a profit."); }
}
#END of FILE Zone:poknowledge  ID:202076 -- Telir_Na`Shalith 


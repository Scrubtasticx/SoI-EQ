sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name. I am Ferin Lightfoot. resident of New Tanaan and scholar in my prime. Now. in my retirement from the excitement of my former life as an adventurer-much like yourself-I am here to offer what knowledge I can in order to help those akin to my former life. In addition to basic supplies which you may need on your adventures I also carry some books which may help liven up any dull. boring spells during your travels.");
quest::say("Greetings. $name. I am Ferin Lightfoot. resident of New Tanaan and scholar in my prime. Now. in my retirement from the excitement of my former life as an adventurer. I am here to offer what knowledge I can in order to help those akin to my former life. In addition to basic supplies which you may need on your adventures I also carry some books which may help liven up any dull. boring spells during your travels."); }
}
#END of FILE Zone:poknowledge  ID:202152 -- Ferin_Lightfoot 


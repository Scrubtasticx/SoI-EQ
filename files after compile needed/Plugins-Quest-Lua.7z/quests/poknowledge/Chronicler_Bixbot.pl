sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome..Welcome! I am so excited to see a new face around New Tanaan. The Great Library of New Tanaan has a plethora of magnificent tomes to tantilize ones mind. I have here some books telling stories of gnomes that have shaped the history of our people. You may borrow them if you are literate in the Gnomish language. The books will return to me when you are finished with them via the enchantments placed upon them by New Tanaan."); }
}
#END of FILE Zone:poknowledge  ID:202023 -- Chronicler_Bixbot 


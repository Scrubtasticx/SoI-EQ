sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail visitor of New Tanaan! If you are an aspiring brewer then perhaps you may be interested in the supplies I have for sale. I assure you my wares are of the highest quality."); }
}
#END of FILE Zone:poknowledge  ID:202081 -- Sirekoth_Eshe 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. $name and good day to thee. The halls of New Tanaan are open to any being of intelligence and self-empowered will that wishes to walk among its halls and libraries. so dinnae be frightened by my seemingly nonconformist presence here. Like my fellow citizens. I have pledged my knowledge to any visitor that has any need or wish of me. though I fear I may only be of use to the druids of the material world. If you believe that I could provide anything of use to you. then do not hesitate to browse my inventory. All of the spells there were penned by my own hand and my stock is always plentiful."); }
}
#END of FILE Zone:poknowledge  ID:202215 -- Wanderer_Kedrisan 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Why. hello there friend and welcome! New Tanaan has seen much excitement these past days. and we are only pleased to accommodate each and every adventurer and scholar who wishes our guidance. If you are a warden of the natural world. then perhaps my wisdom may hold some meaningful importance to you. Come and search my spells. friend. and purchase whatever might catch your eye should you have use or need of it."); }
}
#END of FILE Zone:poknowledge  ID:202214 -- Wanderer_Thermon 


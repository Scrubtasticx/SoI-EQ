sub EVENT_SIGNAL {
	quest::say("I can throw pies too!");
}
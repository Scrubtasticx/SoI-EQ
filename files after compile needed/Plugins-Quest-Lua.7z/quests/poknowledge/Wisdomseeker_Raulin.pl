sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail adventurous traveler! I have been researching the druidic heritages of various Norrathian cultures and have made some interesting finds here in the great library.  Feel free to borrow the books I have found if you like. The sorcery of the library will return the books to their proper places when you are through with them."); }
}
#END of FILE Zone:poknowledge  ID:202166 -- Wisdomseeker_Raulin 


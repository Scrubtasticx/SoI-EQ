sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings visitor! I am a maker and seller of fine ceramics and pottery supplies here in the wondrous city of New Tanaan. If you are practicing the art of pottery then perhaps I can interest you in some of my high quality supplies."); }
}
#END of FILE Zone:poknowledge  ID:202085 -- Dalin_Greskar 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. traveler. and well met. I am Minstrel Gwiar. and it is a pleasure to make the acquaintence of a fellow Norrathian whose career is in its prime. For many years I have been a resident of New Tanaan. taking awe in this place of unhindered wisdom and knowledge without the turmoil and unncessary. petty bias of the material worlds. Aaah. but I get ahead of myself -- please. forgive me. As a citizen of New Tanaan. I have pledged my knowledge to all visitors of our humble plane. Should you hold an interest in the bardic ways. then my inventory might hold some interest to you."); }
}
#END of FILE Zone:poknowledge  ID:202231 -- Minstrel_Gwiar 


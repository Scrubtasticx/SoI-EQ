sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Well. greetings to you good traveler! Perago Crotal is at your service and I guarantee that if its fresh vegetables that you're searching for. you shan't find a rival to my products. Aaah. but I speak too much -- come and see for yourself. my friend."); }
}
#END of FILE Zone:poknowledge  ID:202079 -- Perago_Crotal 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. traveler. and welcome to my shop! All adventurers who brave the toils of the astral realms of the gods need their sustenance and ol' Klen Ironstove provides all the necessities for bakers to produce their wares. Come. peruse my goods and see if there's anything here of interest t'ye."); }
}
#END of FILE Zone:poknowledge  ID:202135 -- Klen_Ironstove 


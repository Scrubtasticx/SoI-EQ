sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Aaah. . . Good day to you. $name. I am Severg O'Danos. once a great alchemist upon Norrath with my brothers. but I have found a new calling here in New Tanaan. If you yourself are a dabbler in the art of potion making. then perhaps my wares will serve you well. Please. feel free to peruse my wares at your leisure."); }
}
#END of FILE Zone:poknowledge  ID:202139 -- Severg_ODanos 


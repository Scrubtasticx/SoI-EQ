sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to [New Tanaan]. friend!  Enjoy your visit and may your quest for enlightenment be a pleasant one!"); }
}
#END of FILE Zone:poknowledge  ID:202100 -- Guardian_Rirak 


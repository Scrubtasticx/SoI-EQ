sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("narrows his wild. blazing eyes upon you. The troll sniffs the air about you. studying you with great care and intent. Eventually. a gruff. hoarse hiss escapes the troll's throat as it backs away. seemingly disinterested and unimpressed. 'How puny you people are now. How spoiled and depraved of true turmoil. chaos. and petty desires for mere wealth. I've hunted down food more impressive and intimidating than you. How disgusting you are. Weakling.'"); }
}
#END of FILE Zone:poknowledge  ID:202058 -- Caonid_Girwil 


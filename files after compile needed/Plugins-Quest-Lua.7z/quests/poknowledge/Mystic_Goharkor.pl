sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("speaks in a hushed voice. barely audible. though the tones of an ancient and long past era emerge through the Iksar's unfamiliar accent. 'Greetings. $name. The mystics of New Tanaan welcome you as an equal. We are scholars and no longer bound by the darkness of our shallow disdain for race or faith. However. each adept must teach only within their knowledge and as a shaman. I must extend my knowledge only to those who are of the same ilk. I have scribed many spells from my memory of the times past on Norrath and these spells are for any that they would aid.'"); }
}
#END of FILE Zone:poknowledge  ID:202182 -- Mystic_Goharkor 


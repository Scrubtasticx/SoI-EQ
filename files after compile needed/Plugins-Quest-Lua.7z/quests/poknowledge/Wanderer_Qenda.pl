sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings to you. traveler. and we warmly welcome you to our midst. New Tanaan holds a limitless fount of knowledge of past history. lore. and research of both the arcane and of faith. If you have come in search of knowledge that would guide you further in the protection of the sacred. natural world as one of its druids. then I may be of humble service to you. Do not hesitate to peruse my inventory should you have wish or need of it. All items that I possess are for a moderate price that will aid the city in furthering our research and guidance of all of Norrath's scholars."); }
}
#END of FILE Zone:poknowledge  ID:202217 -- Wanderer_Qenda 


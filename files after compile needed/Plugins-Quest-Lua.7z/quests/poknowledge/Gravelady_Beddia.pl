sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail seeker of knowledge. There is much to be learned here in New Tanaan of the dark gods of Norrath. I have been searching the great library for tomes pertaining to my patron Bertoxxulous. the Plague Lord and made some interesting finds. If you wish to study the tomes I have uncovered you may borrow them and they will be returned to me by the magic of New Tanaan when you are through."); }
}
#END of FILE Zone:poknowledge  ID:202170 -- Gravelady_Beddia 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Har! Yooz wan be smart like Trogmarz. den yooz read books like Trogmarz! Meez gotz sum books bout ancient trolls yooz can borrow if yooz wantz. Da mojo of da library will bring zem back when yooz are done wit dem."); }
}
#END of FILE Zone:poknowledge  ID:202021 -- Talespinner_Trogmarz 


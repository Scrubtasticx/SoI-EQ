sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Good day to you. $name. I am Culkin Ironstove. one of five merchants that provide goods for those who practice the art of baking. Search my wares if you wish. and know that if I do not possess that which you require. then there are four other Ironstoves who are just as glad as I to aid you where we can."); }
}
#END of FILE Zone:poknowledge  ID:202091 -- Culkin_Ironstove 


sub EVENT_ITEM {
  plugin::return_items(\%itemcount);   
}
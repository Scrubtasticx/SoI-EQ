sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to the Selia district of [New Tanaan].  Be sure to help us to keep it clean!"); }
}
#END of FILE Zone:poknowledge  ID:202109 -- Guardian_Thaowyn 


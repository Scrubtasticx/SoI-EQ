sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("gives a gentile nod of her head in a proper and well-trained greeting. 'Good day to you $name. and may the light of this place enlighten your quest for knowledge and understanding of our existence. I am Norin Khalen. a former enchanter and scholar of the world and a master jeweler of Erudin. In this place. in this time and era. I serve the people and the purpose as a craftswoman. My wares are suited for my art and are available to any aspiring jeweler that may wish to perfect their art whilst in our midst.  I also have the ability to translate special scrolls into knowledge of how to imbue planar gems.'"); }
}
#END of FILE Zone:poknowledge  ID:202083 -- Noirin_Khalen 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I am here to make sure no one flees the arena as a coward."); }
}
#END of FILE Zone:kael  ID:113041 -- a_storm_giant_gladiator 


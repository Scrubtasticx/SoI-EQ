sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I can place things into my vault if you so desire. $name."); }
}
#END of FILE Zone:kael  ID:113082 -- Pollos_Stormkeeper 


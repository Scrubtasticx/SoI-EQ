function event_death_complete(e)
	eq.unique_spawn(113457,0,0,1292,1058,-95,259); -- NPC: The_Avatar_of_War
end

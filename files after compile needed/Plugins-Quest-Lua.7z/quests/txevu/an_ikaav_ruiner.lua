function event_death(e)
e.self:CastSpell(1387, e.self:GetID()); -- Spell: Fulmination
end

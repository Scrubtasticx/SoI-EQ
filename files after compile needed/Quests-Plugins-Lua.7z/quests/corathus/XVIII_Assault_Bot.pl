sub EVENT_SPAWN
{
	quest::SetRunning(1);
	quest::start(9);
}
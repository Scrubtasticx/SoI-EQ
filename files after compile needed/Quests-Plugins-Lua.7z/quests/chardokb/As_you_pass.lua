function event_combat(e)
if (e.joined == true) then
e.self:Emote("into this room, screaming can be heard in the distance.");
eq.depop_with_timer();
end
end

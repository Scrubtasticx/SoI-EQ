function event_combat(e)
if (e.joined == true) then
e.self:Emote("over the jagged bridge, it is clear that you should watch your step as you cross it.");
eq.depop_with_timer();
end
end

function event_combat(e)
if (e.joined == true) then
e.self:Emote("the archway leading deeper into the caves, a chill runs up your spine.");
eq.depop_with_timer();
end
end

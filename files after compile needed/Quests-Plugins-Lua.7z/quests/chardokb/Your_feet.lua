function event_combat(e)
if (e.joined == true) then
e.self:Emote("become submerged in the murky waters below.");
eq.depop_with_timer();
end
end

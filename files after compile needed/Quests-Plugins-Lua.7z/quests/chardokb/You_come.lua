function event_combat(e)
if (e.joined == true) then
e.self:Emote("across a corridor containing four doors and it is unclear which one leads to further danger.");
eq.depop_with_timer();
end
end

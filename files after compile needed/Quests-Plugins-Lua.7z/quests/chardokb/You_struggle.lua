function event_combat(e)
if (e.joined == true) then
e.self:Emote("to keep your balance as you trip over the numerous rocks found at your feet.");
eq.depop_with_timer();
end
end

function event_combat(e)
if (e.joined == true) then
e.self:Emote("enter the room, you take notice of four sarnak in deep meditations. They pay no attention to you and continue on with their incantations.");
eq.depop_with_timer();
end
end

function event_combat(e)
if (e.joined == true) then
e.self:Emote("books are scattered around in this room that seems to be some kind of tactical planning area.");
eq.depop_with_timer();
end
end

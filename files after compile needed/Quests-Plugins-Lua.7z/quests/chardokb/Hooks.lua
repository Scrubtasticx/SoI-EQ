function event_combat(e)
if (e.joined == true) then
e.self:Emote("hang from the ceiling in what seems to clearly be an execution chamber.");
eq.depop_with_timer();
end
end

function event_combat(e)
if (e.joined == true) then
e.self:Emote("further into the haunted halls, you question your reason for adventuring here.");
eq.depop_with_timer();
end
end

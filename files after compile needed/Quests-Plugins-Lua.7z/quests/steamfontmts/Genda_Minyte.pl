sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Hello. I love to come out and gaze at the sky. Isn't it beautiful?");
  }
}
#END of FILE Zone:steamfontmts  ID:448122 -- Genda_Minyte
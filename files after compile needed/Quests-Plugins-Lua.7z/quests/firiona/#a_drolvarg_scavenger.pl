sub EVENT_DEATH_COMPLETE
  {
quest::emote ("yips and falls to the ground. A tattered note appears to be tucked into his armor. ");
  } 
sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to Shar Vahl. We welcome all peaceful merchants and explorers alike. Hostile activity within the city proper is punishable by immediate death."); }
}
#END of FILE Zone:shadeweaver  ID:165177 -- Guard_Ratha_Kalah 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("We must not let the Gor Taku hunters roam through the thicket. They will reduce our food supply by hunting the hoppers we use for meat. They also aid those blasted bandits that raid our merchant routes. We must put a stop to them."); }
}
#END of FILE Zone:shadeweaver  ID:165161 -- Trainee_Parnib 


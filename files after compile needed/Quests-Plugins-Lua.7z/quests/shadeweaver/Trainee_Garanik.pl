sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Karim is right, we cannot let the Gor Taku fool us. The gor taku workers have been gathering a lot of stones lately. I'll wager they are crafting a large quantity of stone weapons to attack us with. I hear they even have a blacksmith making weapons for the Loda Kai."); }
}
#END of FILE Zone:shadeweaver  ID:165160 -- Trainee_Garanik 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings, Ogre Welcome to Shar Vahl."); }
}
#END of FILE Zone:shadeweaver  ID:165176 -- Guard_Shar_Aziz 


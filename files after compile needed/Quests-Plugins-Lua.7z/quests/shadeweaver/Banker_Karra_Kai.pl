sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings $name. I will keep your valuables safe while you hunt in the thickets. Just tap me if you want to store anything here."); }
}
#END of FILE Zone:shadeweaver  ID:165169 -- Banker_Karra_Kai 


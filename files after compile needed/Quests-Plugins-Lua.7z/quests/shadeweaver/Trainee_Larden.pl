sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I agree with Karim. I went on a scouting mission into the gor taku caves, they were definitely building fortifications. They have a slew of builders constructing defences from the stones collected by the workers. We have to strike them before they have finished their preperations for battle."); }
}
#END of FILE Zone:shadeweaver  ID:165159 -- Trainee_Larden 


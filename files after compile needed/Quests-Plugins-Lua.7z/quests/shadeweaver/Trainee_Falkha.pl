sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Pay heed to Captain Karims words. I have seen a Gor Taku scout aiding Loda Kai bandits myself. They are clearly our enemy."); }
}
#END of FILE Zone:shadeweaver  ID:165162 -- Trainee_Falkha 


sub EVENT_AGGRO{
	quest::say("Time to die $name.");
}

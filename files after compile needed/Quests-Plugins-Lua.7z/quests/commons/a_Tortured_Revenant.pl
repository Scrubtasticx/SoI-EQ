# misc. quest dialogue for spell: divine might
#

sub EVENT_DEATH_COMPLETE {
  quest::signalwith(21011,66,0); # NPC: Simon_Aldicott
}

# EOF zone: commons ID: 21031 NPC: a_Tortured_Revenant


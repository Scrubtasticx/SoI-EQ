eq.load_encounter('mpg_subversion');
eq.load_encounter('mpg_foresight');

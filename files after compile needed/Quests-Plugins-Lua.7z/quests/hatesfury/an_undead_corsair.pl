sub EVENT_DEATH_COMPLETE {
  quest::signalwith(228113,33,0); # NPC: #drunk_counter
}
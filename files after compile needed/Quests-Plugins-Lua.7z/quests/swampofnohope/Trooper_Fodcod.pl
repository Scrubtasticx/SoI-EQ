sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. adventurer!  Watch your step and don't get lost in the swamplands.  The frogloks will have you for stew."); }
}
#END of FILE Zone:swampofnohope  ID:83061 -- Trooper_Fodcod 


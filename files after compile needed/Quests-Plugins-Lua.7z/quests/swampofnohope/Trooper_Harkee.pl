sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("If you find yourself deep in the swamp and starving. try foraging.  I am sure you'll find something to eat.  If not. there are always froglok tongues."); }
}
#END of FILE Zone:swampofnohope  ID:83065 -- Trooper_Harkee 


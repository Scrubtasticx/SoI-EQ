function event_death_complete(e)
eq.unique_spawn(226206,0,0,-1316,1073,-144.1,0); -- NPC: Overlord_Ngrub_Brokenskull
eq.depop(226071); --NPC: #Overlord_Ngrub
end

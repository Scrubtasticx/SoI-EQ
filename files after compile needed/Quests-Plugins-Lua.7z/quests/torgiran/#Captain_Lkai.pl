sub EVENT_DEATH_COMPLETE {
        quest::signalwith(226200,33,0); # NPC: #wrank_trigger
}

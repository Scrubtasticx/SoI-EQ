# Zone to timorous event
# Zone: butcher
# AngeloX

sub EVENT_SPAWN
{
	$x = $npc->GetX();
	$y = $npc->GetY();
	quest::set_proximity($x - 50, $x + 50, $y - 50, $y + 50);
}

sub EVENT_ENTER
{
	quest::movepc(96,-3260.10,-4544.56,19.47); # Zone: timorous
}
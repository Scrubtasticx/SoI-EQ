function event_spawn(e)
	e.self:SetRunning(true);
end

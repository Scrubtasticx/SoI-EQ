function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("I've been workin' with Ippledop for years buildin' all kinds of machines. We've created all kinds of waterwheels and steam propulsion systems, so far. We're goin' to hang about and keep creatin' stuff in case more machines are needed to get the ship operatin'.");	
	end
end

function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("What a mighty vessel we have created. There were some fights between good and evil the whole way, but we managed to pull it together! I hope to go visit the Abysmal Sea someday and see what Taelosia is all about.");	
	end
end

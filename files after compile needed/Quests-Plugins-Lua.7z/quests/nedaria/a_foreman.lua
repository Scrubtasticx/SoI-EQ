function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("I've been instructed to stay on land and keep this crew moving. There is no end to this work. You know, a ship is never truly finished. There is always more work to be done. I hear wood is scarce over in Taelosia.");	
	end
end

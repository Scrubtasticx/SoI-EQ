function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("I've known Greba and Berundd for a long time. When Wridarr got asked to come here, I came with pleasure. We've agreed to stay in this lovely area as we must keep sending supplies!  Nothing like living on the waterfront!");	
	end
end

function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("The riggings and details on the Queen of Thorns are extensive. They were not an easy job, to be sure!");	
	end
end

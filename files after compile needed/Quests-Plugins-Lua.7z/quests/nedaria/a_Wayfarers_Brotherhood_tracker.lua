function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("I've been traveling back and forth between the Queen of Thorns and here to be sure none of those foul creatures on Taelosia find their way to Antonica.  We must be careful that they don't come here and try to enslave us too!");	
	end
end

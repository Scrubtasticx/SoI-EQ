function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("Me strong and tuff and been moving big stuffs. Me help make dis big dock and boat dat out in da sea.  Me wants to eat dat halflling on da docks.  I wonder if anyone would miss one halfling?'");	
	end
end

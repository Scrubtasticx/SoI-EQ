function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("Warms me ole salty heart to know that ship made it across them seas!");	
	end
end

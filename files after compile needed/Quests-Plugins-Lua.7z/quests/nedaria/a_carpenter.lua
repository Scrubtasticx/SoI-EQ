function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("I'm going to remain in Nedaria's Landing and make sure there is enough wood and replacement supplies for the ship. Those rough seas are still pummeling the boat.");	
	end
end

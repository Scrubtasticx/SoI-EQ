function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("I will continue to gather supplies for the Abysmal Sea.  There's a lot of food and other supplies needed there to keep everyone fed and warm.");	
	end
end

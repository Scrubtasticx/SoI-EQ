function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("Oy there! Me and me friend Berundd worked together to build the Queen of Thorns. The hull on that boat is the strongest of any boat that exists in Norrath, aye.  There is no way that sea will damage its integrity.  We're staying behind to make any repairs that are needed.");	
	end
end

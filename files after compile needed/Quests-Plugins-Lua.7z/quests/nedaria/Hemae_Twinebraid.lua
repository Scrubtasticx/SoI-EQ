function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("If ye don't already know me by reputation, I'm one of the best carpenters and shipwrights in all of Norrath. I'm proud of what we've accomplished here, though I've had to step in to stop a few fights between them dark-hearted elves and the wood ones.  I'm going to stay and make sure the ship is well taken care of.");	
	end
end

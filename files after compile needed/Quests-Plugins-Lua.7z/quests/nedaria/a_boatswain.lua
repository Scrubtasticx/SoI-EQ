function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Emote("nods at you. 'Gotta keeps up da maintenance for da Queen of Thorns, ya know. We not finished yet.  Never be finished.'");	
	end
end

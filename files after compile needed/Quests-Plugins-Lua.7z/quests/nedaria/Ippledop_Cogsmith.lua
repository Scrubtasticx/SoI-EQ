function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("Cogs and gears and clockworks are my game, friend! I've been told by Morden himself to keep on working to make stuff for the ship. There's still some stuff that needs work.");	
	end
end

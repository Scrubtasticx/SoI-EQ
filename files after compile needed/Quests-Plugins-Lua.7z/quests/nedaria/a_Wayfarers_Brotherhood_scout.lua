function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Emote("eyes you with mild interest and nods.");	
	end
end

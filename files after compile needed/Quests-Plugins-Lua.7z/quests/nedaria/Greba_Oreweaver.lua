function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("Aye, Berundd down there is me husband. I'm 'ere to make sure 'e's well fed and keeps 'is mind on 'is work.");	
	end
end

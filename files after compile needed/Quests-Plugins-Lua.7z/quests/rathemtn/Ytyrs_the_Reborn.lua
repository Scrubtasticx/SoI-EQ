function event_death_complete(e)
	eq.spawn2(50346,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); -- NPC: Ytyrs_Reborn
end
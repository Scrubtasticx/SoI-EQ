sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to the Rathe Mountains hideaway!"); }
}
#END of FILE Zone:rathemtn  ID:50117 -- Innkeep_Troy 


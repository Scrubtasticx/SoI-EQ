eq.load_encounter('pxk');
eq.load_encounter('prt');
eq.load_encounter('pkk');
eq.load_encounter('zmsb');
eq.load_encounter('zmmd');
eq.load_encounter('zmkp');
eq.load_encounter('zmyv');
eq.load_encounter('tmcv');

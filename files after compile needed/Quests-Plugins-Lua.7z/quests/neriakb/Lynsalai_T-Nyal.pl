sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name. The Neriak signal is a newspaper that reports all the events important to the Teir`Dal. which frankly. is the only news that is truly important."); }
}
#END of FILE Zone:neriakb  ID:41023 -- Lynsalai_T`Nyal 


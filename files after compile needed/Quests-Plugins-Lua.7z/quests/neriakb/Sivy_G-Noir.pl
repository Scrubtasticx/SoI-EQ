sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Do you wish to view my wares or have you simply come to gawk in awe?"); }
}
#END of FILE Zone:neriakb  ID:41086 -- Sivy_G`Noir 


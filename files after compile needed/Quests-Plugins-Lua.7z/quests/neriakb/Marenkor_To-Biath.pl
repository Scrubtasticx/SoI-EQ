sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Come in! Come in! Enjoy the sights of the Blind Fish Tavern! We serve the finest alcohol in Neriak!"); }
}
#END of FILE Zone:neriakb  ID:41043 -- Marenkor_To`Biath 


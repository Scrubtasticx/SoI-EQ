sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello $name and welcome to Dawnshroud.'"); }
}
#END of FILE Zone:dawnshroud  ID:174106 -- Yharrv_Valorus 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello there $name. Be sure to speak to Kanthek if you're in need of any armor.'"); }
}
#END of FILE Zone:dawnshroud  ID:174107 -- Thariza_Spiritis 


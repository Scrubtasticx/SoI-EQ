sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Would you mind backing away from me please. I can smell the ale on your breathe. It's not very pleasant.'"); }
}
#END of FILE Zone:dawnshroud  ID:174103 -- Kirthor_Faldyr 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I got the great job of being flag boy. I'm so happy. Can't you tell by the look on my face.' Lendal Robles grins."); }
}
#END of FILE Zone:dawnshroud  ID:174095 -- Lendal_Roble 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Careful of those dawnhoppers. I heard they spit a venom that can cause blindness.'"); }
}
#END of FILE Zone:dawnshroud  ID:174091 -- Kenta_Renlas 


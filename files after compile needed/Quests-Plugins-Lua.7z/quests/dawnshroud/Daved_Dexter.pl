sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello $name.'"); }
}
#END of FILE Zone:dawnshroud  ID:174099 -- Daved_Dexter 


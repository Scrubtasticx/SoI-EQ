sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("What are you doing here? Get outta my tent! It's my tent!!'"); }
}
#END of FILE Zone:dawnshroud  ID:174086 -- Ryklo_Rikes 


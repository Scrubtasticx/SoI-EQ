sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Don't mind the gnome. He's been acting a little strange lately.'"); }
}
#END of FILE Zone:dawnshroud  ID:82429 -- Artah_Medrino 


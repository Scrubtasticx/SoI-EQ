sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Leave me be. I'm trying to get some rest.'"); }
}
#END of FILE Zone:dawnshroud  ID:174088 -- Gaines_Benry 


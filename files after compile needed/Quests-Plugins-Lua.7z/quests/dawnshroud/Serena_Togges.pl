sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome $name! We're here watching some goods for Ryann. I guess you could say we're his personal bodyguards.' Serena smiles."); }
}
#END of FILE Zone:dawnshroud  ID:174096 -- Serena_Togges 


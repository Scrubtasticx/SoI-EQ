sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Whadda you want? Can't you see I'm trying to keep warm and drink my mug of Valtron's Pale Ale? Leave me be.'"); }
}
#END of FILE Zone:dawnshroud  ID:174104 -- Holrik_Falyn 


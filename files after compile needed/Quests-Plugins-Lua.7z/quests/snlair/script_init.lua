eq.load_encounter("tools")

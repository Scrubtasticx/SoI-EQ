function event_death_complete(e)
    eq.signal(392057, 0); -- NPC: #a_madman
end
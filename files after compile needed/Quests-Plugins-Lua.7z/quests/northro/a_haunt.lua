function event_death_complete(e)
  eq.spawn2(392105,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); -- NPC: a_spirit
end
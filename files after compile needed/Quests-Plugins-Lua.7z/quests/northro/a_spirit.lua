function event_death_complete(e)
  eq.spawn2(392106,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); -- NPC: a_guardian_tormentor
end
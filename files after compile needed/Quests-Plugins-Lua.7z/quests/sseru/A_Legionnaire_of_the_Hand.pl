sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name."); }
}
#END of FILE Zone:sseru  ID:159421 -- A_Legionnaire_of_the_Hand 


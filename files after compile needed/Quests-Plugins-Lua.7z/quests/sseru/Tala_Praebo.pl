sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name."); }
}
#END of FILE Zone:sseru  ID:159036 -- Tala_Praebo 


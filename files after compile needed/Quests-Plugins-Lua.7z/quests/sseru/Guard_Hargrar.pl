# Guard Hargrar, spawned by a File Cabinet, in Sanctu Seru

sub EVENT_SPAWN {
  quest::say("Hey! What are you doing in there?!");
}

# EOF


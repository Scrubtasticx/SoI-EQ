sub EVENT_WAYPOINT_ARRIVE {
if($wp == 5) {
	quest::SetRunning(1);
	}
}

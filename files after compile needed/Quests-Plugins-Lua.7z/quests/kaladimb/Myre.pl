sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I am not here to chitchat dear. If you need some gear, I can help. If you want to talk, go find a tavern."); }
}
#END of FILE Zone:kaladimb  ID:67016 -- Myre 


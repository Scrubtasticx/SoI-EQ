sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. I am pleased to report that I am fully stocked. Please have a look at the goods I have for sale."); }
}
#END of FILE Zone:neriaka  ID:40066 -- Sal_Drana 


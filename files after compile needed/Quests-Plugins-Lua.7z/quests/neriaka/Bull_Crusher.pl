sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Huh? Oh hi $name. Youse want to buy sumthin?"); }
}
#END of FILE Zone:neriaka  ID:40049 -- Bull_Crusher 


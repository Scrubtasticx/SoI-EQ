function event_signal(e)
	if e.signal==1 then
		e.self:Say("The spirits and heyokah call upon the greatness of Might. Turn your back on the way of the wasichu and return your steadfast spirit to us all.");
	end
end
function event_signal(e)
	if(e.signal == 1) then
		e.self:Say("Let our collective voice reach the failing strength of the Spirit of Patience who has lost its way among the dismal influences of Discord. Do not give in and bring the strength of your spirit back to us who live on minds and winds.");
	end
end
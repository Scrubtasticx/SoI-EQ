# #champion_controller NPCID 297212

#need to set spawn timer on this npc and off of champion

sub EVENT_SPAWN {
	quest::spawn2(297034,0,0,-39,-8,-439,360); #Mastruq_Champion
}

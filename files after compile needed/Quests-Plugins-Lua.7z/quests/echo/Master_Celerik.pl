sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You have a lot of nerve wandering in here.  We'll be watching you carefully.  Try anything and it will be the last thing you ever try.");
quest::say("I can teach those that follow the Wizardly arts.  If you are not such a one than stop wasting my time."); }
}
#END of FILE Zone:echo  ID:153051 -- Master_Celerik 


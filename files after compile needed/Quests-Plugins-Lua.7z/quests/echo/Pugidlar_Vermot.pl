sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("We know who you are.  Give me the slightest reason and I will call the scounds upon your head."); }
}
#END of FILE Zone:echo  ID:153037 -- Pugidlar_Vermot 


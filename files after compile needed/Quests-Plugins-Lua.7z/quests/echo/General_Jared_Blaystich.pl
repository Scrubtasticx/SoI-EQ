sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You have a lot of nerve wandering in here.  We'll be watching you carefully.  Try anything and it will be the last thing you ever try.");
quest::say("Leave me be.  I have much work to do and cannot be distracted right now."); }
}
#END of FILE Zone:echo  ID:153048 -- General_Jared_Blaystich 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You have a lot of nerve wandering in here.  We'll be watching you carefully.  Try anything and it will be the last thing you ever try.");
quest::say("I may be a Magician of small stature. but that belies my not so small power.  If you are worthy I may be able to teach you."); }
}
#END of FILE Zone:echo  ID:153050 -- Master_Yurian 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You have a lot of nerve wandering in here.  We'll be watching you carefully.  Try anything and it will be the last thing you ever try."); }
}
#END of FILE Zone:echo  ID:153049 -- Master_Wirgus 


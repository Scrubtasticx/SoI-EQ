sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You have a lot of nerve wandering in here.  We'll be watching you carefully.  Try anything and it will be the last thing you ever try.");
quest::say("If you are not a practitioner of the dark arts then I cannot help you.  Leave my presence."); }
}
#END of FILE Zone:echo  ID:153052 -- Master_Nochtar 


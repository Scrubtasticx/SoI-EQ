sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Fall in line, soldier! Hrmm. . . You are a soldier, aren't you?");
  }
}
#END of FILE Zone:povalor  ID:208062 -- Johaan_Landro
sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Please leave me be.");
  }
}
#END of FILE Zone:povalor  ID:208054 -- Ranin_Tredbul
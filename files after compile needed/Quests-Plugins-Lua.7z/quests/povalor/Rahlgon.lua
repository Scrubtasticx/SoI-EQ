function event_signal(e)
eq.depop();
end

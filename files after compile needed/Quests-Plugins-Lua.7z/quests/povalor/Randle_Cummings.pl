sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Hello there, $name. If you seek to rest your laurels and stock up on food or water for the upcoming struggles ahead, I can provide you with any basic supplies you may need.");
  }
}
#END of FILE Zone:povalor  ID:208036 -- Randle_Cummings
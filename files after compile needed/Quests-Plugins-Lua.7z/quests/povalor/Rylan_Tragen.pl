sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Hail, strange one. Have you come to explore the wasteland? If you have, I wish you good fortune, but that is not a journey I seek to undertake!");
  }
}
#END of FILE Zone:povalor  ID:208065 -- Rylan_Tragen
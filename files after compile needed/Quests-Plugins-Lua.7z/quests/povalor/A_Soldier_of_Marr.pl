sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Move along, we have much work to do and little time to do it.");
  }
}
#END of FILE Zone:povalor  ID:208037 -- A_Soldier_of_Marr
sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Well met, $name. Do you hear the call of honor as these brave soldiers I teach do? You would do well to learn from the lessons of your ancestors, for valor is its own reward.");
  }
}
#END of FILE Zone:povalor  ID:208066 -- Sergeant_Amon_Tillan
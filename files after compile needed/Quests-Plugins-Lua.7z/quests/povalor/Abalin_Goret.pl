sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Hmm? Are you talking to me? Oh, I guess you must be. I am new here and some of the Soldiers still haven't fully accepted me. Give me some time, they will see.");
  }
}
#END of FILE Zone:povalor  ID:208057 -- Abalin_Goret
sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::emote("grumbles under his breath.");
  }
}
#END of FILE Zone:povalor  ID:208058 -- Rammoc_Mills
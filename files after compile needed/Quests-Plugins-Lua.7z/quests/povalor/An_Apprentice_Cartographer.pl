sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::emote("nods in your direction, recognizing your presence, then returns to his work.");
  }
}
#END of FILE Zone:povalor  ID:208035 -- An_Apprentice_Cartographer
sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::emote("remains silent.");
  }
}
#END of FILE Zone:povalor  ID:208053 -- Boluen_Areden
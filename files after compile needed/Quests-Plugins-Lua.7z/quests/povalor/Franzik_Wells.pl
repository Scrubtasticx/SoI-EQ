sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Good day. Although I do not mind your presence, I do ask to be left alone, for I am trying to concentrate. Please forgive my lack of gregariousness. Do come another time.");
  }
}
#END of FILE Zone:povalor  ID:208064 -- Franzik_Wells
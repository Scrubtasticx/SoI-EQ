eq.load_encounter('gukg');

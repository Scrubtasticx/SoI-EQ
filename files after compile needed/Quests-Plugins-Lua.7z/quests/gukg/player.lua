function event_enter_zone(e)
  e.self:ClearCompassMark(); 
end

function event_death(e)
	e.self:CastSpell(1017, e.self:GetID()); -- Fish Nova upon death
end

function event_death_complete(e)
	if(math.random(100) < 45) then
		eq.spawn2(64092,0,0,133,-22,-283,0); --Swirlspine_Guardian (64092)
	end
end

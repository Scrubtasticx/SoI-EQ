function event_spawn(e)
	eq.set_timer("depop",1500000);
end

function event_timer(e)
	eq.depop();
end

sub EVENT_SPAWN {
  quest::settimer(1,5);
}

sub EVENT_TIMER {
  $check_named = $entity_list->GetMobByNpcTypeID(292018);
  if($check_named == 0) {
    quest::spawn2(292021,0,0,-1227,-628,-5,0); # NPC: #Tqiv_Qukret_the_Furious
    quest::depop_withtimer();
  }
}
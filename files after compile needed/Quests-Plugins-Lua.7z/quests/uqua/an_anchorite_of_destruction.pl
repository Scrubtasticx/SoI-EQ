sub EVENT_DEATH_COMPLETE {
  quest::signalwith(292069,1); # NPC: #Vrex_Barxt_Qurat
}
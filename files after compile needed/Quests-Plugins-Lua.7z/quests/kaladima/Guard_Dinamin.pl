sub EVENT_WAYPOINT_ARRIVE {
if($wp eq 6) {
	plugin::DoAnim(kneel);
	}
if($wp eq 21) {
	plugin::DoAnim(kneel);
	}
}
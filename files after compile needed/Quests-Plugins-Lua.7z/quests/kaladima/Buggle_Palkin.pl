sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name.  I am Gretta Mottle's assistant. Buggle.  I tend to the bakery for her during the night.  I can only make one thing though..  Meat Pie.  Poor Gretta is in desperate need of help right now so I'm trying to learn how to make muffins for her."); }
}
#END of FILE Zone:kaladima  ID:6194 -- Buggle_Palkin 


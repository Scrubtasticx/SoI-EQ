sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome!! Welcome!! Have a seat at the bar and try some of my rich. dwarven ale!!"); }
}
#END of FILE Zone:kaladima  ID:60037 -- Hanamaf_Darkfoam 


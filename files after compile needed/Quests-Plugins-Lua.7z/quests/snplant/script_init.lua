eq.load_encounter("stonemites")
eq.load_encounter("area_emotes")

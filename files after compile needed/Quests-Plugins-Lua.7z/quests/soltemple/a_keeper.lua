function event_death_complete(e)
eq.spawn2(80040, 0, 0, e.self:GetX(), e.self:GetY(),  e.self:GetZ(),  e.self:GetHeading()); -- NPC: a_blazing_elemental
end

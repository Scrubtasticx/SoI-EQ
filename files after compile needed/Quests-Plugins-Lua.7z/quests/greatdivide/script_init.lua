eq.load_encounter('ring_war');

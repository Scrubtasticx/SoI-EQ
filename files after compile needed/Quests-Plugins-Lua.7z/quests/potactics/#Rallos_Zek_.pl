sub EVENT_SIGNAL {
	quest::unique_spawn(214109,0,0,500,11,169.1,381.2);	# Spawn Mini Rallos and depop when told to
	quest::depop();
}

# End of File  Zone: PoTactics  ID: 214052  -- #Rallos_Zek_

sub EVENT_SIGNAL {

quest::spawn2(207033,0,0,-635,890,-1240,260); # needs_heading_validation
quest::spawn2(207033,0,0,-633,926,-1247,380); # NPC: A_skinless_creature
quest::spawn2(207033,0,0,-658,961,-1241,0); # NPC: A_skinless_creature
quest::spawn2(207033,0,0,-736,971,-1240,284); # NPC: A_skinless_creature
quest::spawn2(207033,0,0,-738,890,-1240,414); # NPC: A_skinless_creature
quest::spawn2(207033,0,0,-738,890,-1240,414); # NPC: A_skinless_creature
quest::spawn2(207033,0,0,-871,931,-1242,0); # NPC: A_skinless_creature
quest::spawn2(207033,0,0,-949,952,-1239,0); # NPC: A_skinless_creature
quest::spawn2(207032,0,0,-959,921,-1240,0); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-1084,924,-1240,68); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-1083,1003,-1240,200); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-957,1001,-1240,0); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-930,989,-1433,144); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-901,993,-1439,178); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-846,920,-1448,480); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-756,923,-1433,492); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-753,918,-1640,0); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-754,988,-1640,0); # NPC: A_flayed_horror
quest::spawn2(207032,0,0,-859,990,-1641,176); # NPC: A_flayed_horror
quest::spawn2(207031,0,0,-789,997,-1633,316); # NPC: An_Unimaginable_Horror
}


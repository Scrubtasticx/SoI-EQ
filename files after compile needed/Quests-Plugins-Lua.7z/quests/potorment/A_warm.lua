function event_combat(e)
if (e.joined == true) then
e.self:Emote("red mist falls from above. The slick substance has no time to settle before it is hungrily absorbed by every surface.");
eq.depop_with_timer();
end
end

function event_combat(e)
if (e.joined == true) then
e.self:Emote("squirts from the porous walls that surround you!");
eq.depop_with_timer();
end
end

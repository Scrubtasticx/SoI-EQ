#This is just some flavor text for the failed crypt raider, who holds one of the scrolls for the seventh Greenmist quest.

sub EVENT_DEATH_COMPLETE {
  quest::say("Never.. to feel the mist.. again..");
}

#Submitted by Jim Mills
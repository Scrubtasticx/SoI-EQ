function event_slay(e)
  eq.get_entity_list():MessageClose(e.self, true, 100, MT.SayEcho, "A devastating pooka cackles a bit as a body falls to the ground.")
end

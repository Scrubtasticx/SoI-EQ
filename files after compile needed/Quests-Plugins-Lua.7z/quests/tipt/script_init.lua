eq.load_encounter("cragbeasts")
eq.load_encounter("ghosts")

function event_death(e)
  e.self:CastSpell(2321, 0); -- Spell: Energy Burst
end

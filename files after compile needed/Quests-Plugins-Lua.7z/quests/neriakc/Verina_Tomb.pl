# Test of Illusion - enchanter epic - Innoruuk's Word
# 

sub EVENT_AGGRO {
  quest::say("Hatred is the Universal Truth.");
}

# EOF Zone: neriakc ID: 42112 NPC: Verina_Tomb


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hey! What's up? If you want some real fun. go downstairs at the Maiden's Fancy."); }
}
#END of FILE Zone:neriakc  ID:42040 -- Molon_T`Plth 


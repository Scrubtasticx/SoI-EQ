

sub EVENT_DEATH_COMPLETE {
	quest::signal(172168,1);  #signal for a chance to spawn Heratius Grolden
}

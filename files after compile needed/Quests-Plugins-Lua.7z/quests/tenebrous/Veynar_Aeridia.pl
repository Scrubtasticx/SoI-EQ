sub EVENT_DEATH_COMPLETE {
	quest::signal(172136,0); # NPC: #invis_johanius_one
}

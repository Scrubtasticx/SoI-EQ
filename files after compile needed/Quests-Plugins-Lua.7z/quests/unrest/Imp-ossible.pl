sub EVENT_SPAWN {
	quest::shout("Oh, someone got past Jack? Impressive. Well, come and get me, mortals!");
}

sub EVENT_DEATH_COMPLETE {
	quest::shout("Nooo! I cannot be defeated! Its imp-ossible!");
	quest::spawn2(63101,0,0,17,579,3.1,308); # NPC: Werewolf_of_DOOOOOOOM
}

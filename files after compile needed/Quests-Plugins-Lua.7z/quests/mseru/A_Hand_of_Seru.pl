sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name.");}
}
#END of FILE Zone:mseru  ID:168050 -- A_Hand_of_Seru 


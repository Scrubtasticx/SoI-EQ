function event_death_complete(e)
	eq.spawn2(301071,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); --#a_mindburrow_feran
end
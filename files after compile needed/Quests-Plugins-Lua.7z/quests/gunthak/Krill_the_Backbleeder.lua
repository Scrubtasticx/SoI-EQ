function event_death_complete(e)
	eq.signal(224122,2,1000); -- NPC: Lairyn_Debeian
end
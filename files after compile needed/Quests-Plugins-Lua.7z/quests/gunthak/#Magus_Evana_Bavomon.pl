# NPC: ##Magus_Evana_Bavomon (224227)
# Angelox

#sub EVENT_COMBAT{
 #   quest::say(" ");
#}

sub EVENT_DEATH_COMPLETE{
  quest::say("Your naivete is astounding, you will never escape with your lives.");
 }

# EOF zone: Gunthak
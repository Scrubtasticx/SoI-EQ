#npc - assorted death text
#zone - Gunthak
#by Angelox

sub EVENT_DEATH_COMPLETE {
    quest::say("For killing me, you can only pray they kill you quickly.");
 }
#really says; "Dark blood trickles from dry lips as the citizen falls."
# NPC:an_emaciated_zombie (224005)
# Angelox

#sub EVENT_COMBAT{
 #   quest::say("I always enjoy getting a good kill in before breakfast.");
#}

sub EVENT_DEATH_COMPLETE{
  quest::emote("'s corpse attracts curious flies as it plops wetly to the ground.");
 }

# EOF zone: Gunthak
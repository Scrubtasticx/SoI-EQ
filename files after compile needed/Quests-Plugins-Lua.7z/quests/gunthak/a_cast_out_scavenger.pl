# NPC:a_cast_out_scavenger
# Angelox

#sub EVENT_COMBAT{
 #   quest::say("I always enjoy getting a good kill in before breakfast.");
#}

sub EVENT_DEATH_COMPLETE{
  quest::emote("''s corpse says 'What a place for it all to end.");
 }

# EOF zone: Gunthak
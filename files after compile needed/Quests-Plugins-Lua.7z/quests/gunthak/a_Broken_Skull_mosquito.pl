# NPC:a_Broken_Skull_mosquito (224047)
# Angelox

#sub EVENT_COMBAT{
 #   quest::say("I always enjoy getting a good kill in before breakfast.");
#}

sub EVENT_DEATH_COMPLETE{
  quest::emote("'s corpse splatters, forming a dark stain on the terrain.");
 }

# EOF zone: Gunthak
# NPC:a_Broken_Skull_nifilik (224026)
# Angelox

#sub EVENT_COMBAT{
 #   quest::say("I always enjoy getting a good kill in before breakfast.");
#}

sub EVENT_DEATH_COMPLETE{
  quest::emote("'s corpse oozes fluids from its broken shell.");
 }

# EOF zone: Gunthak
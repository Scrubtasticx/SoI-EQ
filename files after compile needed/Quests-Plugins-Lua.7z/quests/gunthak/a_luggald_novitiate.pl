#npc - assorted death text
#zone - Gunthak
#by Angelox

sub EVENT_DEATH_COMPLETE {
    quest::say("I shall be avenged!");
 }
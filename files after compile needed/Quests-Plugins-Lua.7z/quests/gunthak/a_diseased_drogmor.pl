# NPC: a_diseased_drogmor
# Angelox

sub EVENT_COMBAT{
    quest::emote("snorts and lumbers forth to attack!");
}

sub EVENT_DEATH_COMPLETE{
  quest::emote("clutches at you one last time, then grows cold.");
 }

# EOF zone: Gunthak
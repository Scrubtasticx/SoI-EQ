# NPC:aa_Broken_Skull_scorpion (224027)
# Angelox

#sub EVENT_COMBAT{
 #   quest::say("I always enjoy getting a good kill in before breakfast.");
#}

sub EVENT_DEATH_COMPLETE{
  quest::emote("'s corpse falls back, its legs jerking spastically.");
 }

# EOF zone: Gunthak
sub EVENT_DEATH_COMPLETE {
  quest::spawn2(57117,0,0,$x,$y,$z,$h); # NPC: corrupted_brownie
}
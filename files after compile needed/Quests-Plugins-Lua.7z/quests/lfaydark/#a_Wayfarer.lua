function event_death_complete(e)
	eq.signal(57150,1); -- NPC: Taskmaster_Mirot
end

 
sub EVENT_DEATH_COMPLETE {
 quest::signalwith(215483,1,0); # NPC: #Chamberlain_Trigger
}

#Submitted by Jim Mills
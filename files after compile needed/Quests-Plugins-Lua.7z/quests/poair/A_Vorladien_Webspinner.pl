sub EVENT_DEATH_COMPLETE {
	quest::signalwith(215461, 5);#Signal to #Dust_Trigger
}
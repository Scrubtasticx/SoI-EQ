sub EVENT_DEATH_COMPLETE {
quest::signalwith(215455,2,1); # NPC: #Mist_Trigger
}

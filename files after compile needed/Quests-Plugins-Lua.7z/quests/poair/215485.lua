function event_combat(e)
if (e.joined == true) then
eq.spawn2(215065, 17, 0, -487, -733, 108.5, 392); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 17, 0, -487, -733, 108.5, 392); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 17, 0, -487, -733, 108.5, 392); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 17, 0, -487, -733, 108.5, 392); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 17, 0, -487, -733, 108.5, 392); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 17, 0, -487, -733, 108.5, 392); -- NPC: A_Marauding_Stormrider
eq.depop_with_timer();
end
end

sub EVENT_DEATH_COMPLETE {
quest::signalwith(215461,1,1); # NPC: #Dust_Trigger
}

function event_combat(e)
if (e.joined == true) then
eq.spawn2(215065, 16, 0, -451, -597, 105.56, 501); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 16, 0, -451, -597, 105.56, 501); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 16, 0, -451, -597, 105.56, 501); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 16, 0, -451, -597, 105.56, 501); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 16, 0, -451, -597, 105.56, 501); -- NPC: A_Marauding_Stormrider
eq.spawn2(215065, 16, 0, -451, -597, 105.56, 501); -- NPC: A_Marauding_Stormrider
eq.depop_with_timer();
end
end

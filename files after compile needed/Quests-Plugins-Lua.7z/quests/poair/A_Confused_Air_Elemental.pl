sub EVENT_DEATH_COMPLETE {
	quest::signalwith(215453, 4);#Signal to #Smoke_Trigger
}
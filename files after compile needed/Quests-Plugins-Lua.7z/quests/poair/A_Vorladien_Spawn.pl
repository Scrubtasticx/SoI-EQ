sub EVENT_DEATH_COMPLETE {
quest::signalwith(215461,2,1); # NPC: #Dust_Trigger
}
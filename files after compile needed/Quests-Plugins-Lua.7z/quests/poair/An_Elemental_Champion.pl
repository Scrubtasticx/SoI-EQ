sub EVENT_DEATH_COMPLETE {
quest::signalwith(215453,1,1); # NPC: #Smoke_Trigger
}

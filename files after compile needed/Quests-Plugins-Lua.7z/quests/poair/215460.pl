sub EVENT_DEATH_COMPLETE {
    quest::spawn2(215460,0,0,$x,$y,$z,$h); # NPC: an_erratic_arachnid
}

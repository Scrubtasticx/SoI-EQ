sub EVENT_DEATH_COMPLETE {
quest::signalwith(215450,2,1); # NPC: #Air_Trigger
}

sub EVENT_DEATH_COMPLETE {
quest::signalwith(215450,1,1); # NPC: #Air_Trigger
}

sub EVENT_SIGNAL {
  quest::say("I shall eat well tonight!");
  quest::depop();
}
sub EVENT_SIGNAL {
  quest::say("Your servos belong to me!");
  quest::depop();
}
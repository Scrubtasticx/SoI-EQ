sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello.  I love to come out and gaze at the sky.  Isn't it beautiful?"); }
}
#END of FILE Zone:steamfont  ID:56138 -- Genda_Minyte 


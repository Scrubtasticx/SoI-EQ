sub EVENT_SIGNAL {
  quest::say("Victory is mine!");
  quest::depop();
}
sub EVENT_SIGNAL {
{ quest::depop(); }
}

# End of File  Zone: PoFire  ID: 217082  -- Omni_Magus_Crato
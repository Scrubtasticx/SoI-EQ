sub EVENT_SIGNAL {
{ quest::depop(); }
}

# End of File  Zone: PoFire  ID: 217079  -- Javonn_the_Overlord
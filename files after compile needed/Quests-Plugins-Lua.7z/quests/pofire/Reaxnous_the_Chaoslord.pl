sub EVENT_SIGNAL {
{ quest::depop(); }
}

# End of File  Zone: PoFire  ID: 217080  -- Reaxnous_the_Chaoslord
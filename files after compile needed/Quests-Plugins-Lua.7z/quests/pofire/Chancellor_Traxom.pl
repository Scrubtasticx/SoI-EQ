
sub EVENT_SIGNAL {
{ quest::depop(); }
}

# End of File  Zone: PoFire  ID: 217083  -- Chancellor_Traxom
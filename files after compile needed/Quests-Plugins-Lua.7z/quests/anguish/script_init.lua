eq.load_encounter('keldovan');
eq.load_encounter('jelvan');
eq.load_encounter('ture');
eq.load_encounter('hanvar');
eq.load_encounter('amv');
eq.load_encounter('omm');
eq.load_encounter('augs');
# NPC: Tutorial kobolds (However, Rookfynn is a Goblin...)
# Angelox

sub EVENT_COMBAT {
#  quest::emote("brandishes razor sharp claws and circles inward.");
}

sub EVENT_DEATH_COMPLETE {
#  quest::emote("unleashes a lupine yelp as it collapses on the floor.");
}

# EOF zone: Tutorialb NPC:#Rookfynn.pl
eq.load_encounter('mmcc');

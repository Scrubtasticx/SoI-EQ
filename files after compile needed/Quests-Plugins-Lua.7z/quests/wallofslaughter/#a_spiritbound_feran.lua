function event_death_complete(e)
	eq.spawn2(300093, 0, 0, e.self:GetX(), e.self:GetY(), e.self:GetZ(), e.self:GetHeading()); -- NPC: #a_spiritbound_chimera
	eq.spawn2(300093, 0, 0, e.self:GetX(), e.self:GetY(), e.self:GetZ(), e.self:GetHeading()); -- NPC: #a_spiritbound_chimera
	eq.spawn2(300093, 0, 0, e.self:GetX(), e.self:GetY(), e.self:GetZ(), e.self:GetHeading()); -- NPC: #a_spiritbound_chimera
end


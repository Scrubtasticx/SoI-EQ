eq.load_encounter('redwing')

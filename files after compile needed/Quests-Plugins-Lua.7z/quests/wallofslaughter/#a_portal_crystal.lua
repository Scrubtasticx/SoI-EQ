function event_death(e)
  eq.signal(300063,80); -- NPC: #Tarn_Icewind
end

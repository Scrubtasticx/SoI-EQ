sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Look at you.  Encumbered you could be.  Encumbered with great treasures.  Treasures from all corners of Kunark.  Go and find them. but first you will need to outfit yourself with packs of fine craftsmanship.  Lucky for you. that is what I do best... craft packs."); }
}
#END of FILE Zone:cabeast  ID:3052 -- Klok_Vednir 


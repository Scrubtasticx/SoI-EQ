sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I have no time for conversation.  Go. and leave me to my duties."); }
}
#END of FILE Zone:cabeast  ID:5094 -- Trooper_Byzin 


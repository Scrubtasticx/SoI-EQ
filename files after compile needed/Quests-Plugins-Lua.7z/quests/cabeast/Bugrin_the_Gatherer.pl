sub EVENT_SPAWN {
  quest::say("You will never take me alive!!");
}

sub EVENT_DEATH_COMPLETE {
  quest::say("hisss.. You will never stop the.. Radiant.. Green..");
}
sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("It is best for you to buy some of my armor.  It is far better than anything a lizard could create on his own.  You do the adventuring and leave the stitching to good old Scaznar.  Tailoring is my rebirth."); }
}
#END of FILE Zone:cabeast  ID:3045 -- Klok_Scaznar 


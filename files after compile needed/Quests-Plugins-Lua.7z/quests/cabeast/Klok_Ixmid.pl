sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Searching for the sparklies are we?  Look and see.  See what I have found on my journeys into the outlands."); }
}
#END of FILE Zone:cabeast  ID:3029 -- Klok_Ixmid 


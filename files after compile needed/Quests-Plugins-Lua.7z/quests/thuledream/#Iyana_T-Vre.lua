
function event_spawn(e)
	e.self:DoAnim(3);
end

function event_say(e)
	e.self:Emote("groans, shivering slightly despite her position near the fire.  Beads of sweat are formed on her forehead, overlaying darkened veins over a relatively pale Teir'dal face.");
end
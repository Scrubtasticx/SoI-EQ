function event_say(e)
	e.self:Emote("stoically looks out into the distance, unmoving and silent.");
end

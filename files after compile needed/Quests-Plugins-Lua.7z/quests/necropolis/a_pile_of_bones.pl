sub EVENT_COMBAT {
	quest::depop_withtimer();
        quest::spawn2(123097,0,0,$x,$y,$z,$h); # NPC: #a_dragon_construct
}

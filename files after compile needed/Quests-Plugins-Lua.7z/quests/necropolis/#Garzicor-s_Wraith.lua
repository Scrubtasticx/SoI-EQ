function event_death_complete(e)
	eq.spawn2(123196,0,0,983,1518,-124,0); -- #Spirit_of_Garzicor (123196)
	eq.spawn2(123197,0,0,1045,1433,-106,0); -- #Spirit_of_Garzicor_ (123197)
end

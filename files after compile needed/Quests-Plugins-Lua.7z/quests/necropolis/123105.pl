#
#

sub EVENT_SIGNAL {
  if ($signal == 99) {
    quest::say("Chita ve ni ne, ni ne Neb!");
    quest::signalwith(123045,101,1000); # NPC: Neb
  }
}

# EOF zone: necropolis ID: 123105 NPC: paebala_spirit_talker


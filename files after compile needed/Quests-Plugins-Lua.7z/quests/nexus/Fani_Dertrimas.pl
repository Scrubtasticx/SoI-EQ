sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to the Nexus! Down each stairway is a passage that leads out from the Nexus. Through those passages you will find the great trade city of Shadow Haven. the Bazaar. and the cavern systems that lead to the surface of Luclin. Also. located in each tunnel is a teleport pad that can return you to Norrath. There is much information to be gathered here. be sure to speak to everyone and ask lots of questions. Farewell. $name."); }
}
#END of FILE Zone:nexus  ID:152013 -- Fani_Dertrimas 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Another traveler has come to our lands. Rinkes. I wish you the best of luck wherever your travels may take you. $name."); }
}
#END of FILE Zone:nexus  ID:152009 -- Defender_Rhazor 


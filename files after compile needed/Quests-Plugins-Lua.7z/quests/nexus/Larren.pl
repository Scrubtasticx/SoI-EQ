sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Oh. welcome $name!  Beyond me is perhaps the best place in all of Lu... well. Norrath now too.  You really need to check it out for yourself. It is the perfect place for a trader like yourself to find the best deal on any item around!"); }
}
#END of FILE Zone:nexus  ID:152011 -- Larren 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name. The passages extending from the heart of Luclin take you east to Shadow Haven. south to the Bazaar. west in the direction of the city Sanctus Seru. and north to the city of Shar Vahl.  Before heading in any one of these directions. speak to the keepers at the entrances."); }
}
#END of FILE Zone:nexus  ID:152014 -- Kardador_Tarsinian 


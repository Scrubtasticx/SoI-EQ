sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail $name. behind me lies the path to the Odus platform. Please refrain from combat while in the Nexus as we have not thoroughly tested how the teleporters would react if exposed to certain magics."); }
}
#END of FILE Zone:nexus  ID:152006 -- Defender_Karrik 


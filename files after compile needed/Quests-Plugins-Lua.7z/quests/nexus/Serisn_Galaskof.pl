sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hi there $name. If you could please try to keep away from Eslof. He is going through a very tough time now as his brother was part of the mining contingent that was working on this here entrance to the Paludal caverns when it caved in sealing up the entrance. We have troops working on the other side around the clock to clear up the rocks. Sorry for any trouble."); }
}
#END of FILE Zone:nexus  ID:6836 -- Serisn_Galaskof 


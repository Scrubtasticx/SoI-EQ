sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Down this passage you will find the entrance to the Bazaar. a great place to find that trinket you have been looking for. Don't forget to head to Shadowhaven after you stop here."); }
}
#END of FILE Zone:nexus  ID:152010 -- Defender_Galson 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello. $name.  It is great to see new faces again around the Nexus.  We are lucky to have some of the finest and most powerful magicians working hard to aid our cause."); }
}
#END of FILE Zone:nexus  ID:152008 -- Defender_Rinkes 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to the center of Luclin $name. this is a very magical place. The magic that emanates from here can be felt even on the surface. Don't forget to speak to as many of us as you can before you venture far."); }
}
#END of FILE Zone:nexus  ID:152012 -- Persy_Clutches 


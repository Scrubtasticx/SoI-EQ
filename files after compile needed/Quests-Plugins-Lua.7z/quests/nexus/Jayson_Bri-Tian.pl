sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Ahh. welcome $name. It is good to see more and more people visiting now that the portals are functional. It took us many. many years to understand the magical powers of Luclin. Whether through dumb luck or divine intervention. we have succeeded in opening the gate back to Norrath.  How long it will stay open. no one knows. My colleagues and I are here to maintain and watch for changes in the Nexus- should anything happen. you will be notified. Safe travels."); }
}
#END of FILE Zone:nexus  ID:152015 -- Jayson_Bri`Tian 


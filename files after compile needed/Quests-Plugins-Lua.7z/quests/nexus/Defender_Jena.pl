sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Through this very hallway lies the city of Shadowhaven. On your way there. you will notice a small room that contains a miniature version of the spires. If you have no means of personal transportation back to Norrath. these teleports will take you there. Be sure to speak to the attendant at the teleport for more information."); }
}
#END of FILE Zone:nexus  ID:152016 -- Defender_Jena 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("No time to talk I gotta get my brother out! Im coming Lareso!"); }
}
#END of FILE Zone:nexus  ID:150073 -- Eslof_Runsalark 


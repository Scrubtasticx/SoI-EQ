function event_say(e)
	if(e.message:findi("Hail")) then
		e.self:Say("Hail. yerself.  I'm sure ye've better things to do than to bother a man makin' his potions. then. eh?");
	end
end

-------------------------------------------------------------------------------------------------
-- Converted to .lua using MATLAB converter written by Stryd and manual edits by Speedz
-- Find/replace data for .pl --> .lua conversions provided by Speedz, Stryd, Sorvani and Robregen
-------------------------------------------------------------------------------------------------

eq.load_encounter("king")
eq.load_encounter("queen")


function event_say(e)
	if(e.message:findi("hail")) then
		e.self:Say("Just cuz we live in da swamp don't mean youse gotta stay in da dark. Da Swamp News got all da news. And it ain't go no big wurds in it like da other news'es out dair.");
	end
end

-- END of FILE Zone:feerrott  ID:49071 -- Klob_Pulp
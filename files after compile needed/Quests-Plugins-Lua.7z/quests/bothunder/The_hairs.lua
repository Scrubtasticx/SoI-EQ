function event_combat(e)
if (e.joined == true) then
e.self:Emote("on your body stand on end with static electricity.");
eq.depop_with_timer();
end
end

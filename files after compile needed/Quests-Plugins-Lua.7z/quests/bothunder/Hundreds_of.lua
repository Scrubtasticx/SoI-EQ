function event_combat(e)
if (e.joined == true) then
e.self:Emote("funnel storms dance about your legs and feet.");
eq.depop_with_timer();
end
end

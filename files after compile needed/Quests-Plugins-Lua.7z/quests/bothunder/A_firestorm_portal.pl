sub EVENT_SIGNAL {
	if($signal == 1) {
		quest::spawn2(209118,0,0,$x,$y,$z,$h); # NPC: A_firestorm_elemental_
	}
}

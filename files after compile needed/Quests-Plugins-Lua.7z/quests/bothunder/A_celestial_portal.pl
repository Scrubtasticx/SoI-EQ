sub EVENT_SIGNAL {
 if($signal == 1) {
  quest::spawn2(209116,0,0,$x,$y,$z,$h); # NPC: An_animated_meteor
 }
}

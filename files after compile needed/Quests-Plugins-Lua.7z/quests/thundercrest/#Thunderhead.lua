function event_death_complete(e)
eq.spawn2(340399,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); -- NPC: #Stormfront
eq.spawn2(340399,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); -- NPC: #Stormfront
eq.spawn2(340399,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); -- NPC: #Stormfront
eq.zone_emote(15,"The Raging Thunderhead grows in size and strength as it incorporates another lesser storm.");
end

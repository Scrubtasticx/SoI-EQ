sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Gah! Look at ye sneekin' up on people! Dun ye have somethin' better ye could be doin'?  I'm tryin t'keep track o'the inventory. so the last thing I be needin' is a shamblin' pile o'noise like yerself buggin' me!  Off wit' ye. now!"); }
}
#END of FILE Zone:potranquility  ID:203061 -- Dubbel_Strohbarrel 


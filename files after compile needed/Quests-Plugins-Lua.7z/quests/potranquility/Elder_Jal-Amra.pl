sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("greets you with a nod and quietly says. 'Welcome to our study. Please refrain from venturing in beyond this lobby. The elders are involved in maintaining a deep meditative state. They must not be disturbed. If an elder wishes to speak to you. one of their aids will fetch you.'"); }
}
#END of FILE Zone:potranquility  ID:203037 -- Elder_Jal`Amra 


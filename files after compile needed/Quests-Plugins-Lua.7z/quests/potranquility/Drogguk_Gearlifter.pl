sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("gives a husky grunt as he contiues a slow pace of brushing grains of sand from between the windmill gears. 'Hullo. Drogguk working. Drogguk have no time fer talk. only time fer work. Always only time fer work.'"); }
}
#END of FILE Zone:potranquility  ID:203034 -- Drogguk_Gearlifter 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("was humming as you approached.  As you hail her. the humming turns into a surprisingly loud outburst of song!  Her arms flail and fish guts fly. as she dances around with troll-like gracefulness!"); }
}
#END of FILE Zone:potranquility  ID:203025 -- Zurmsa_Grulm 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::emote("mumbles an inaudible phrase and continues to stare at the large table in front of him."); }
}
#END of FILE Zone:potranquility  ID:203005 -- Weavereader_Dox`Atyr 



sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("looks more interested in finishing his dinner than talking to you."); }
}
#END of FILE Zone:potranquility  ID:203026 -- Kalin_Reddin 


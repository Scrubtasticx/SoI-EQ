sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("gives a rumbling growl that catches you slightly off-guard in memory of the brutish. merciless ogres upon your native world. Urgla narrows an eye at seeing your brief moment of discomfort at her reaction. A crooked smile crosses her almost grotesque maw. as if she were amused. and then she promptly returns to counting boxes without a word."); }
}
#END of FILE Zone:potranquility  ID:203036 -- Urgla_Fishbrains 


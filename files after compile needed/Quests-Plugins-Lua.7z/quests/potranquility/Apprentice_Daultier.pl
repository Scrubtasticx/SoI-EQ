sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("whispers. 'Please return to the lobby. as not to disturb the elders.'"); }
}
#END of FILE Zone:potranquility  ID:203038 -- Apprentice_Daultier 


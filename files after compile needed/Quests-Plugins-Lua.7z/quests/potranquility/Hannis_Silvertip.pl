sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("What are you doing back here?  We appreciate people trying to help. but I've got my hands full trying to keep Zurmsa from stepping on Trila as is.  I don't need another set of feet tromping around in here. Be on your way. traveler. There's nothing of interest for you here. I'm quite certain."); }
}
#END of FILE Zone:potranquility  ID:203048 -- Hannis_Silvertip 


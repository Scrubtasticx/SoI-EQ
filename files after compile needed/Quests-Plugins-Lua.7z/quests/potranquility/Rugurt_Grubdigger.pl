sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Huh. what you want? Don' scare off da fishes. less you want me to toss you in with dem."); }
}
#END of FILE Zone:potranquility  ID:203028 -- Rugurt_Grubdigger 


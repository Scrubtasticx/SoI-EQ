#generic soulbinder quest
sub EVENT_SAY { 
	plugin::soulbinder_say($text);
}
#END of FILE Zone:potranquility  ID:107251 -- Soulbinder_Derith 


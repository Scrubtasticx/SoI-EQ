sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome friend. Should you need to store any of your belongings or coin. you'll find that this area is quite secure and your precious belongings will remain safe in our care.  You'll find Aelisian to be a fair broker if you wish to pick up a little extra clang in your coffers."); }
}
#END of FILE Zone:potranquility  ID:203052 -- Jasila_Maqul 


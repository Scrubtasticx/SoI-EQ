sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("doesn't seem to notice you.  Her concentration is set on trying to reach the tray that rests on the table before her."); }
}
#END of FILE Zone:potranquility  ID:203047 -- Trila_Cabbageroll 


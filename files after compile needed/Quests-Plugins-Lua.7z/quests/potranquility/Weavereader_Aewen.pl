sub EVENT_SAY { 
if($text=~/Hail/i){
quest::emote("scans the tapestry that rests before her. Her eyes don't stop their twitching analysis of the material in your address to her."); }
}
#END of FILE Zone:potranquility  ID:203006 -- Weavereader_Aewen 


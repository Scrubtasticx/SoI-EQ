sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You are welcome to observe. but please keep your voice down.  We need to maintain a peaceful atmosphere if we are to continue our reading."); }
}
#END of FILE Zone:potranquility  ID:203004 -- Weavereader_Ralmajir 



sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("gives a gentle nod in recognition and mutual respect. Her voice then spills forth in an almost whispered hiss. 'Greetings. $name. I would invite you to keep me company while I finish my meal. but I am afraid that I am almost through.  There really is not much here that suits my palate. but Zurmsa is at least kind enough to keep the place sstocked with bloodwater for me.  Enjoy your meal.'"); }
}
#END of FILE Zone:potranquility  ID:203046 -- Sariliz_Grizka 


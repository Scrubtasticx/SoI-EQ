
sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Excuse me. I am trying to finish my meal."); }
}
#END of FILE Zone:potranquility  ID:203023 -- Saluk_Tramuj 


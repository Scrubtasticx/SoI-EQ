sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I am Rugresch.  I cratch da fur from da skins and other tings dat dey brings me.  Da cratchins is wut dey makes da weavin strings from.  All day long. cratch. . . cratch. . . cratch. . . but it is wut I do.  I needs ta get back ta work.  I gots lots more ta do."); }
}
#END of FILE Zone:potranquility  ID:203043 -- Rugresch_Tragguk 


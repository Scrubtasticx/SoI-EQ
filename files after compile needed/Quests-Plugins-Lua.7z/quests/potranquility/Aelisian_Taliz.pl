sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail friend. Please. take your time and have a look around at your leisure. We have something to accommodate any need or suit any requirement a traveler may possess in this unruly time."); }
}
#END of FILE Zone:potranquility  ID:203053 -- Aelisian_Taliz 


function event_spawn(e)
	eq.disable_spawn2(151562);
end

function event_death_complete(e)
	eq.enable_spawn2(151562);
end

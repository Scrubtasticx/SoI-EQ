function event_say(e)
	if(e.message:findi("hail")) then
		e.self:Say("Hello there! If ya don't mind I'd like to get some rest in my room here. I just arrived from Kaladim and need some rest to recover from the journey. Dwarves were'nt meant to sail the ocean ya know. It's a good thing we've got strong stomachs though or I'd be a few pounds lighter!");
	end
end

-- END of FILE Zone:freporte -- Grendig
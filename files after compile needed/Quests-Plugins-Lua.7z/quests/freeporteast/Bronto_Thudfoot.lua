function event_signal(e)
	e.self:Say("You said it, boss!  Stay clear of taking sides and you should be just fine, young one.");
end

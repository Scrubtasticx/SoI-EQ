sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You seek to extinguish the hunger of the flesh.  You have come to the right place."); }
}
#END of FILE Zone:cabwest  ID:3342 -- Lybar 


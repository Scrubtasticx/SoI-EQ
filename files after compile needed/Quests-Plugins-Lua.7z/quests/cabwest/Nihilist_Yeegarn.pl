sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Looking for a good read?  You should visit the guild houses.  They have tomes which have been scribed for sale."); }
}
#END of FILE Zone:cabwest  ID:3697 -- Nihilist_Yeegarn 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Can't you see I'm on duty?!!  If you wish to converse. might I suggest the Tink N' Babble tavern near the Temple of Terror?"); }
}
#END of FILE Zone:cabwest  ID:5144 -- Trooper_Tygar 


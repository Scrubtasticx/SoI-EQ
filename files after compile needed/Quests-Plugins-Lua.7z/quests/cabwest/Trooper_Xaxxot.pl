sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("The purchase of a water extractor would be wise for any lizard who expects to venture deep into the wilds of Kunark."); }
}
#END of FILE Zone:cabwest  ID:5146 -- Trooper_Xaxxot 


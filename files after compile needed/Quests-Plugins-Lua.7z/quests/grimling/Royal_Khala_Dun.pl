sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Well met, friend.  May I be of assistance?"); }
}
#END of FILE Zone:grimling  ID:167115 -- Royal_Khala_Dun 


#a_grimling_painsoother

sub EVENT_DEATH_COMPLETE {
  quest::signalwith(167663,1,0); # NPC: #grimling_counter
} 
#a_grimling_gruntling

sub EVENT_DEATH_COMPLETE {
  quest::signalwith(167663,1,0); # NPC: #grimling_counter
} 
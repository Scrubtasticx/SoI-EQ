#Arcanist_Ukigit

sub EVENT_DEATH_COMPLETE {
  quest::say("You will die...");
 } 
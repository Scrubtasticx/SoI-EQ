sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Well met, friend.  May I be of assistance?"); }
}
#END of FILE Zone:grimling  ID:167126 -- Merchant_Hamarr 


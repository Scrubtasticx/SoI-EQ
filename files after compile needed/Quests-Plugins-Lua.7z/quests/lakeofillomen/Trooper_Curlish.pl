sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Have you tried to drink from the lake?  It is poisoned with salt!  If you plan on venturing to the far side of the lake, you had best visit one of the Kloks to purchase a Water Extractor."); }
}


#END of FILE Zone:lakeofillomen  ID:5096 -- Trooper_Curlish 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I've heard rumors of disappearing fishermen on the Lake of Ill Omen. Strange sightings abound. If I were you. I'd do my best to avoid those waters."); }
}

#END of FILE Zone:lakeofillomen  ID:5098 -- Trooper_Digdul 


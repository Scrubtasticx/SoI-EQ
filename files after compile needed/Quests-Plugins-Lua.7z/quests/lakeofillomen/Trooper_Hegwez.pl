sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. adventurer!  Stay close to the gates or risk your life.  The Lake of Ill Omen is aptly named."); }
}

#END of FILE Zone:lakeofillomen  ID:5113 -- Trooper_Hegwez 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("My father once dove to the depths of the lake.  He said there were many dangers. but reported seeing structures still standing and glints of treasure in the muck below."); }
}

#END of FILE Zone:lakeofillomen  ID:5121 -- Trooper_Kylpog 


sub EVENT_DEATH_COMPLETE {
  quest::spawn2(285086,0,0,$x,$y,$z,$h); # NPC: #Cube_Fragment
  quest::spawn2(285087,0,0,$x,$y,$z,$h); # NPC: #Cube_Fragment
  quest::spawn2(285088,0,0,$x,$y,$z,$h); # NPC: #Cube_Fragment
  quest::spawn2(285089,0,0,$x,$y,$z,$h); # NPC: #Cube_Fragment
  quest::spawn2(285090,0,0,$x,$y,$z,$h); # NPC: #Cube_Fragment
  quest::spawn2(285091,0,0,$x,$y,$z,$h); # NPC: #Cube_Fragment
}
function event_signal(e)
eq.spawn2(221007,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); --spawn targettable gargs
eq.depop();
end

sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("Haha!! Another victory for our lord Cazic-Thule!  May your corpse be a dread-inspiring sign to those who travel this forest!");
  }
}
#END of FILE Zone:toxxulia  ID:..... -- a_heretic_prophet  (needs version copied from tox)
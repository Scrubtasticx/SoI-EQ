sub EVENT_WAYPOINT_ARRIVE {
  if($wp == 2) {
    quest::SetRunning(1);
  }
}
sub EVENT_DEATH_COMPLETE {
  quest::setglobal("grisk", 1, 5, "f");
}
sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("I have no time to answer questions, whelp! Now, leave this place before the sting of death finds the life in your veins!");
  }
}
#END of FILE Zone:toxxulia  ID:414058 -- Shintar_Vinlail
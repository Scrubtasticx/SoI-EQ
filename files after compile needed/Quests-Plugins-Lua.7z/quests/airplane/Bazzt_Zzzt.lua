function event_death_complete(e)
	eq.set_global("sirran","6",3,"M20");
	eq.spawn2(71058,0,0,234,-1078,812,384); --Sirran the Lunatic
end

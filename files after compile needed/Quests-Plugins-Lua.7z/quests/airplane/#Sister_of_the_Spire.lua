function event_death_complete(e)
	eq.set_global("sirran","7",3,"M20");
	eq.spawn2(71058,0,0,-960,-1037,1093,128); -- NPC: Sirran_the_Lunatic
end

-------------------------------------------------------------------------------------------------
-- Converted to .lua using MATLAB converter written by Stryd
-- Find/replace data for .pl --> .lua conversions provided by Speedz, Stryd, Sorvani and Robregen
-------------------------------------------------------------------------------------------------

function event_spawn(e)
	e.self:SetRace(69);
	e.self:SetTexture(1);
	e.self:ChangeSize(4);
end

-- DEVELOPER: Congdar
-------------------------------------------------------------------------------------------------
-- Converted to .lua using MATLAB converter written by Stryd
-- Find/replace data for .pl --> .lua conversions provided by Speedz, Stryd, Sorvani and Robregen
-------------------------------------------------------------------------------------------------

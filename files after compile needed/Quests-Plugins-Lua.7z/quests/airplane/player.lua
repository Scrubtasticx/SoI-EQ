function event_enter_zone(e)
	e.self:BuffFadeAll();
end

-- END of FILE Zone:airplane  ID:player
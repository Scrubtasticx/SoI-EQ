sub EVENT_SPAWN {
  plugin::StraightPath(500,600);

}

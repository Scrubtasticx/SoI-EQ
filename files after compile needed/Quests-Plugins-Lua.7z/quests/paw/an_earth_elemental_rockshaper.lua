function event_death_complete(e)
	if(math.random(100) < 10) then
		eq.unique_spawn(18015,0,0,-130,871,-21,256); -- Earthmaster Grundag
	end
end

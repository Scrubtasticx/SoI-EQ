function event_death_complete(e)
	if(math.random(100) < 10) then
		eq.unique_spawn(18013,0,0,213,734,-19,412); -- Tidemaster Aquinius
	end
end

function event_death_complete(e)
	if(math.random(100) < 10) then
		eq.unique_spawn(18007,0,0,-53,1076,4,200); -- Windlord Brizoris
	end
end

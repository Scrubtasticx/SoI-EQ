function event_death_complete(e)
	if(math.random(100) < 10) then
		eq.unique_spawn(18010,0,0,183,1217,5,384); -- Blazemaster Arnab
	end
end

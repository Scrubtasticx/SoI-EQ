function event_death(e)
eq.zone_emote(15, "As the guardian falls, the fragile crystal of the beacon cracks.  Energy trapped within the crystal explodes into the room.");
eq.zone_emote(15, "A thunderous explosion rocks the spire as the beacon atop the tower shatters.");
end

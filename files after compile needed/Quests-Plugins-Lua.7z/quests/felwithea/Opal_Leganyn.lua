function event_say(e)
	if(e.message:findi("koada dal falchion")) then
		e.self:Say("Koada'Dal Falchions are highly specialized weapons crafted of the finest mithril. The weapon must be forged in the unique Koada'Dal Forge and you will need a curved blade mold. a hilt and a pommel Mold. some morning dew. and a folded sheet of mithril. If you are a faithful follower of the All Mother then you may craft a magical falchion using moonlight temper instead of the morning dew and forging an emerald imbued by a cleric into the weapon at the time of its creation.");
	end
end

-- END of FILE Zone:felwithea  ID:61048 -- Opal_Leganyn
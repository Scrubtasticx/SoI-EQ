-- Sonsa Fromp //33088// ##Drogerin##

function event_say(e)
    if (e.message:findi("hail")) then
		e.self:Say("Hello, traveler. It is so good to meet you. I am Sonsa Fromp, tailor surpreme. I have been known to make the finest leather armor this side of the wall. Feel free to inspect my merchandise. Buy plenty. This is how I put food on the table.");
	end
end

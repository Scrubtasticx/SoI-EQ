eq.load_encounter('Misty');

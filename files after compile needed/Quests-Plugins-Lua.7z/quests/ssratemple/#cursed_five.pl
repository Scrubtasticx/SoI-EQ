sub EVENT_SIGNAL {
	quest::depop_withtimer();
}
sub EVENT_DEATH_COMPLETE {
	quest::signal(162277);#cursed_eight
}
sub EVENT_DEATH_COMPLETE {
	quest::signal(162272);#cursed_three
}
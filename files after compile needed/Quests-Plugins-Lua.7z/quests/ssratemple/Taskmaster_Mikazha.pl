sub EVENT_DEATH_COMPLETE {
	quest::signal(162275);#cursed_six
}
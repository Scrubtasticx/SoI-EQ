sub EVENT_DEATH_COMPLETE {
	quest::signal(162273);#cursed_four
}
sub EVENT_DEATH_COMPLETE {
	quest::signalwith(162255,1,0); # NPC: #cursed_controller
}



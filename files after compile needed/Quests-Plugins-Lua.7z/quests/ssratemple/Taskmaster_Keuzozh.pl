sub EVENT_DEATH_COMPLETE {
	quest::signal(162271);#cursed_two
}
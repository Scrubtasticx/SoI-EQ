sub EVENT_DEATH_COMPLETE {
	quest::signal(162274);#cursed_five
}
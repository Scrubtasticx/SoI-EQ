sub EVENT_DEATH_COMPLETE {
	quest::signal(162270);#cursed_one
}
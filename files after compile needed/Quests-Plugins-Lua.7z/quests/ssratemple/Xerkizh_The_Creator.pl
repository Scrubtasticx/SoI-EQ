#Just a little flavor for when XTC kills someone.

sub EVENT_SLAY {
  quest::say("Odd, we normally have to drag sacrifices kicking and screaming, but this one all but throws himself at us.");
}

#Submitted by: Jim Mills
sub EVENT_DEATH_COMPLETE {
	quest::signal(162276);#cursed_seven
}
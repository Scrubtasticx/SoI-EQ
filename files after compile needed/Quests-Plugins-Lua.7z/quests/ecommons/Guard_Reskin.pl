sub EVENT_SIGNAL{
	if(($signal==1) && ($x==159) && ($y==-143)){
		quest::say("All quiet, Sergeant.");
	}
}
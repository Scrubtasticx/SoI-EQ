sub EVENT_SIGNAL{
	if(($signal==1) && ($x==3016) && ($y==-289)){
		quest::say("All quiet, Sergeant.");
	}
}
sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("By Cazic-Thule. I am going to kill him!  If he keeps up that endless chatter.. Oh. hello there. $name.  Please feel free to peruse my wares."); }
}
#END of FILE Zone:paineel  ID:75101 -- Winnla_Crestus 


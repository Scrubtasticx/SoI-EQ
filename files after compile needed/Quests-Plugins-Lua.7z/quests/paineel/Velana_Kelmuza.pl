sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello there. $name. I hope you are faring well this day."); }
}
#END of FILE Zone:paineel  ID:75046 -- Velana_Kelmuza 


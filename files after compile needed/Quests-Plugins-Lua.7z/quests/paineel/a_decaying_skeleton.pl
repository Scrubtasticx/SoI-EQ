sub EVENT_SAY { 
if($text=~/Ahhh, I feel much better now.../i){
quest::say("Arrrreeeee!"); }
}
#END of FILE Zone:paineel  ID:38001 -- a_decaying_skeleton 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Have you spoken with Danus?  If not. I suggest you do. so that I will not waste my breath further."); }
}
#END of FILE Zone:paineel  ID:75087 -- Kilevra_Natasu 


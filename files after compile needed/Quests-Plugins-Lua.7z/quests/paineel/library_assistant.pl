sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Lots to do! Many books to place and scrolls to file! Feel free to browse but. please. don't make a mess!"); }
}
#END of FILE Zone:paineel  ID:75017 -- library_assistant 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Oh. hello there. and welcome to my humble store.  We have everything you might need here. for just about anywhere you'd want to go.  Matter of fact. a party supplied themselves for a trip into Old Paineel just moments ago!"); }
}
#END of FILE Zone:paineel  ID:75080 -- Geomar_Hapera 


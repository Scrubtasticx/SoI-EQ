sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. $name!  I thought I heard the clink of coins and now. here you stand!  Please feel free to browse through my stock."); }
}
#END of FILE Zone:paineel  ID:75106 -- Brettas_Norval 


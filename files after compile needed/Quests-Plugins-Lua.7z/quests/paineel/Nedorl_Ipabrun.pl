sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Buy. or leave.  Make up your mind.  I have no time for idle chitchat."); }
}
#END of FILE Zone:paineel  ID:75084 -- Nedorl_Ipabrun 


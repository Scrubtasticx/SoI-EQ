sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hey you!  You watch yourself.  These items are priceless.  You break it. you buy it!"); }
}
#END of FILE Zone:paineel  ID:75096 -- Tentus_Brackmar 


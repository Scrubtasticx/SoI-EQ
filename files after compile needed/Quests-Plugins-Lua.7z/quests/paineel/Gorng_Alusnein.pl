sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello.  Be careful what you say to Iva.  She has been rather touchy lately.  She seems as if she is waiting for something to happen.  What. I know not."); }
}
#END of FILE Zone:paineel  ID:75103 -- Gorng_Alusnein 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hrm?  Yes. yes?  Buy something. or leave me alone!"); }
}
#END of FILE Zone:paineel  ID:75108 -- Dovan_Sires 


sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to the Fortune's Fancy. $name!  I carry only the finest jewels and jewelry in all the land.  All of the [charges and accusations] made against me are obviously false. as you can see by my beautiful wares."); }
}
#END of FILE Zone:paineel  ID:75078 -- Dannis_Faleet 


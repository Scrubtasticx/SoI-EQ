sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Yes. yes.  Scrolls I have. scrolls you need.  Make up your mind quickly.  I don't have all day to stand here talking to you."); }
}
#END of FILE Zone:paineel  ID:75088 -- Danus_Kelmun 


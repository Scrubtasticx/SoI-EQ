sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello. $name.  Thankyou for coming in and looking at our wares.  We should have just about everything you need if you wish to take a trip."); }
}
#END of FILE Zone:paineel  ID:75079 -- Rallia_Hapera 


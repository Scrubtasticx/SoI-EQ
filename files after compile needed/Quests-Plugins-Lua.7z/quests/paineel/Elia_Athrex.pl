sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello.  Do you need something or did you merely wish to grace me with your oh-so-delightfully perfumed breath?"); }
}
#END of FILE Zone:paineel  ID:75020 -- Elia_Athrex 


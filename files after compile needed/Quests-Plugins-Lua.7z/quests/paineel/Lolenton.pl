# animation does not currently work for skeleton models.   leaving it for possible future fix.

#sub EVENT_SPAWN {
#  quest::settimer("repeat", 3);
#}

#sub EVENT_TIMER {
#  plugin::DoAnim("cheer");
#}

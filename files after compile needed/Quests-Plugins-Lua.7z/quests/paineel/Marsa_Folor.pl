sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello there. $name!  Can't take your valuables with you?  Weighing you down. are they. $name?  Leave them with me.  In my capable hands and in the hands of my capable staff. they will be safe from prying eyes and quick hands!"); }
}
#END of FILE Zone:paineel  ID:75100 -- Marsa_Folor 


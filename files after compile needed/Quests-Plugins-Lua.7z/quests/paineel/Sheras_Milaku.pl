sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello. $name.  Feel free to peruse my wares but waste not my time with idle browsing if you do not intend to purchase something."); }
}
#END of FILE Zone:paineel  ID:75107 -- Sheras_Milaku 


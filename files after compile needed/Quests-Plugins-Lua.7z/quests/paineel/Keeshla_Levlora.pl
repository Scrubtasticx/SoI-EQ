sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail and well met. $name.  I am Keeshla Levlora. a resident necromancer of this beautiful city.  If you are a practitioner of the dark arts under our lord Cazic-Thule. know that you are welcome here."); }
}
#END of FILE Zone:paineel  ID:75045 -- Keeshla_Levlora 


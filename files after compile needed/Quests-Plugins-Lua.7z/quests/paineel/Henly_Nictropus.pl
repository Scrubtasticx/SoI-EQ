sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("The Dark Truth reports the news without all the usual propaganda and lies spewed by the mouthpieces of other Kingdoms and principalities. Buy a copy today for just a few silver and find out the real truth behind current events."); }
}
#END of FILE Zone:paineel  ID:75114 -- Henly_Nictropus 


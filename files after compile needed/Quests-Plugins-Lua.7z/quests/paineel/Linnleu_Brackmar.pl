sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name.  My wares are few but valuable. including books of research into the less widely known arts of necromancy.  Perhaps you should have a look."); }
}
#END of FILE Zone:paineel  ID:75082 -- Linnleu_Brackmar 


function event_death_complete(e)
	-- spawn Zebuxoruk
   eq.spawn2(223212,1,0,-635.485,-1109.51,-2.8105,120); -- NPC: Zebuxoruk
end

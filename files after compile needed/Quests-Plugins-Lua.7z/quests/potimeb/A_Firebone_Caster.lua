function event_death_complete(e)
	-- send a signal to the phoboplasm that I died
	eq.signal(223098,1); -- NPC: Bertoxxulous
end
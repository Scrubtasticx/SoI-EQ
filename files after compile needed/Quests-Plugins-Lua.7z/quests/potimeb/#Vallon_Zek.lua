-- fake VZ splits
function event_combat(e)
  if (e.joined == true) then
    eq.set_timer("OOBcheck", 6 * 1000);
  else
    eq.stop_timer("OOBcheck");
  end
end


function event_timer(e)
if(e.timer=="OOBcheck") then
eq.stop_timer("OOBcheck");
	if (e.self:GetX() < 250) then
		e.self:GotoBind();
		e.self:WipeHateList();
	else
		eq.set_timer("OOBcheck", 6 * 1000);
	end
end
end

function event_signal(e)
if (e.signal == 2) then
eq.spawn2(347009,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); -- NPC: a_drachnid_spawn
end
end

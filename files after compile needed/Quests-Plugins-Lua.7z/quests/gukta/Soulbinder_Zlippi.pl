#generic soulbinder quest
sub EVENT_SAY {
  plugin::soulbinder_say($text);
}
#END of FILE Zone:gukta  ID:90652 -- Soulbinder_Zlippi 


#::: Author: Akkadius
#::: Description: Used to commify strings
#::: Usage: plugin::commify(12302302); Would output value 12,302,302
sub commify {
   local $_  = shift;
   s{(?<!\d|\.)(\d{4,})}
    {my $n = $1;
     $n=~s/(?<=.)(?=(?:.{3})+$)/,/g;
     $n;
    }eg;
   return $_;
}

return 1;
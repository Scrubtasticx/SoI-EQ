sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Huh? Oh hi $name. Youse want to buy sumthin?"); }
}
#END of FILE Zone:oggok  ID:49063 -- Erung 


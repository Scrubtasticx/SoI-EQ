function event_death_complete(e)
eq.spawn2(301075,0,0,940,106,-938.43,0); -- NPC: #a_reclusive_girplan
eq.zone_emote(15, "Attracted by the recent commotion, a reclusive Girplan emerges from its hiding spot.");
end
-- 3rd girplan spawns 4th

function event_death_complete(e)
eq.spawn2(301076,0,0,-252,1324,-721.67,0); -- NPC: #a_reclusive_girplan
eq.zone_emote(15, "Attracted by the recent commotion, a reclusive Girplan emerges from its hiding spot.");
end
-- 4th girplan spawns 5th

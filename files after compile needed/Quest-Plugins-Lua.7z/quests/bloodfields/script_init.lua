eq.load_encounter('gaz');
eq.load_encounter('war');

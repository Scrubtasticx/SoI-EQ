function event_death_complete(e)
eq.spawn2(301074,0,0,-135,996,-622.81,0); -- NPC: #a_reclusive_girplan
eq.zone_emote(15, "Attracted by the recent commotion, a reclusive Girplan emerges from its hiding spot.");
end
-- 2nd girplan spawns 3rd

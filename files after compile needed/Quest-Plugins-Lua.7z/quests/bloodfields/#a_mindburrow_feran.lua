function event_death_complete(e)
	eq.spawn2(301072,0,0,e.self:GetX(),e.self:GetY(),e.self:GetZ(),e.self:GetHeading()); -- NPC: #a_burnmuzle_feran
end
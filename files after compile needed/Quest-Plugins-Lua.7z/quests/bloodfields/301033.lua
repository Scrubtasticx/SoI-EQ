function event_death_complete(e)
eq.spawn2(301073,0,0,-1292,61,-910.61,0); -- NPC: #a_reclusive_girplan
eq.zone_emote(15, "Attracted by the recent commotion, a reclusive Girplan emerges from its hiding spot.");
end
-- 1st girplan spawns 2nd

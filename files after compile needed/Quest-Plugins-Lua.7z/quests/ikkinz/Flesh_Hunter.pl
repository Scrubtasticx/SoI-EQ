sub EVENT_DEATH_COMPLETE {
  quest::signalwith(294142,1,0); # NPC: #Trigger_Ikkinz_2
}
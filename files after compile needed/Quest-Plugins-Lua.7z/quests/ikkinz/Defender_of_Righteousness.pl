sub EVENT_AGGRO {
  quest::settimer(1,1);
}

sub EVENT_TIMER {
  if($x > 475 || $x < 190 || $y > -280 || $y < -380) {
    $npc->GMMove(446,-348,3,384);
  }
}

sub EVENT_DEATH_COMPLETE {
  quest::signalwith(294141,2,0); # NPC: #Trigger_Ikkinz_1
}

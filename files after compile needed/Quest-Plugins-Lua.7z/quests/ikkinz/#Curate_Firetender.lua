#Curate_Firetender (294612)
function event_death_complete(e)
	eq.zone_emote(0,"Curate Firetender's corpse is burned by embers before finally laying dead upon the ground");
end
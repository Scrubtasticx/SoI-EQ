function event_death_complete(e)
	eq.signal(294614, 1); -- NPC: #Trigger_Ikkinz_4
	eq.zone_emote(0,"Alter Warden's corpse crumbles to pieces almost instantly.  Whatever is the driving force behind this creature must be siphoning the energy back into itself.");
end

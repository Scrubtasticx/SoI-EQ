function event_combat(e)
if (e.joined == true) then
e.self:Emote("of the golems opens up before you. Their massive forms have made great indentations in the ground.");
eq.depop_with_timer();
end
end

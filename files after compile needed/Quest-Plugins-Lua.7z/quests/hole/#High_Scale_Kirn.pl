sub EVENT_SPAWN {
 if($class eq "Shaman") {
  quest::attack($name);
 }
}

#Submitted by: Jim Mills (Gilmore Girls`Is`Awesome`XOXO)
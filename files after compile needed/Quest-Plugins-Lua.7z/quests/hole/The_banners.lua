function event_combat(e)
if (e.joined == true) then
e.self:Emote("of this once great city are hung on the wall with pride. The tattered and torn fabric is rough to the touch, yet very brittle.");
eq.depop_with_timer();
end
end

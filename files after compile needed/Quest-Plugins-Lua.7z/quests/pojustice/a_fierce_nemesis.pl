sub EVENT_SIGNAL {
   if ($signal == 0) {
      quest::depop();
   }
} 
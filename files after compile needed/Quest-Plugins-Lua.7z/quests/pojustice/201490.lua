function event_death_complete(e)
	eq.signal(201450, 904); -- NPC: #Event_Torture_Control
end

--7th hammer tribunal
--tribunal 201077
function event_signal(e)
   if (e.signal == 1) then
	 e.self:DoAnim(3);
   end
end
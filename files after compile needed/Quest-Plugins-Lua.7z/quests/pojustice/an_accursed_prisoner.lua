function event_death_complete(e)
	eq.signal(201451, 2); -- NPC: #Event_Stoning_Control
end

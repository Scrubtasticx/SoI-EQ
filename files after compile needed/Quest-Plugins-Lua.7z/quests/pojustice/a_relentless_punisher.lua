function event_death_complete(e)
	eq.signal(201451, 9); -- NPC: #Event_Stoning_Control
end

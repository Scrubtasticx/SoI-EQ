function event_death_complete(e)
	eq.signal(201449, 2); -- NPC: #Event_Lashing_Control
end

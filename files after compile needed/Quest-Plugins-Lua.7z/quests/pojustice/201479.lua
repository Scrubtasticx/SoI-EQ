function event_death_complete(e)
	eq.signal(201450, 901); -- NPC: #Event_Torture_Control
end

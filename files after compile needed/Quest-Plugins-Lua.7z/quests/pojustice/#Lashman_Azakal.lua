function event_death_complete(e)
	eq.signal(201449, 1); -- NPC: #Event_Lashing_Control
end

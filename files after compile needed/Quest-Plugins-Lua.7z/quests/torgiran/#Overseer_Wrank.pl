sub EVENT_SIGNAL {
  if ($signal == 66){
     quest::depop();
}
 }
sub EVENT_DEATH_COMPLETE {
  quest::signalwith(226205,45,0); # NPC: #overlord_counter
}
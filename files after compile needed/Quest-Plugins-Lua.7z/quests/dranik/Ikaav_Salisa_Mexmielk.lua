--dranik/Ikaav_Salisa_Mexmielk.lua
--Spawned as part of #Battlemaster_Rhorious.lua event

function event_death(e)
  eq.signal(336240,91); --Signal to Rhorious_Chest_Spawner.lua
end

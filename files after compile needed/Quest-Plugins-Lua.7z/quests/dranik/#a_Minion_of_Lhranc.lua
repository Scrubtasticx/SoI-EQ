--dranik/Minion_of_Lhranc.lua NPCID 
--Shadowknight Epic 2.0
function event_death_complete(e)
	eq.signal(336098,1); -- NPC: #Filligno_the_Slayer
end

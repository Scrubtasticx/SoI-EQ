eq.load_encounter("maidens");

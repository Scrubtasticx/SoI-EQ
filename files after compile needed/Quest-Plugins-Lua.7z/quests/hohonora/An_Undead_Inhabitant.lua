function event_death_complete(e)
eq.spawn2(211055, 0, 0, e.self:GetX(), e.self:GetY(),  e.self:GetZ(),  e.self:GetHeading()); -- spawns multiple A_Undead_Miniature on death (211055)
eq.spawn2(211055, 0, 0, e.self:GetX(), e.self:GetY(),  e.self:GetZ(),  e.self:GetHeading()); -- spawns multiple A_Undead_Miniature on death (211055)
end

function event_death_complete(e)
eq.spawn2(211056, 0, 0, e.self:GetX(), e.self:GetY(),  e.self:GetZ(),  e.self:GetHeading()); -- spawns multiple A_Rabid_Wrulon_Pup on death (211056)
eq.spawn2(211056, 0, 0, e.self:GetX(), e.self:GetY(),  e.self:GetZ(),  e.self:GetHeading()); -- spawns multiple A_Rabid_Wrulon_Pup on death (211056)
end

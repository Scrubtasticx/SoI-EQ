sub EVENT_SAY {
  if($text=~/hail/i) {
    quest::say("You have set foot upon the sacred grounds of the Shrine of Bertoxxulous. You had best have business here or this dirt shall become your grave.");
  }
}
#END of FILE Zone:qcat  ID:45016 -- Argyn_Shieldstan
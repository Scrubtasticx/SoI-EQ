################################
# NPC: Ronn_Castekin.pl
# Zone: Qcat
# By Andrew80k

sub EVENT_DEATH_COMPLETE {
  quest::say("Argh!.. Mer.. o..na.. it's.. not.. your fault.. arhhh...");
}